/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import junit.framework.TestCase;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class AssignmentTest extends TestCase {
    
    public AssignmentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    @Override
    public void setUp() {
    }
    
    /**
     *
     */
    @After
    @Override
    public void tearDown() {
    }

    /**
     * Test of process method, of class Assignment.
     */
    @Test
    public void testProcess() throws Exception {
        System.out.println("process");
        Operand left = new Variable("a");
        Operand right = new ResultOperand("8");
        RegisterKeep registers = new RegisterKeep();
        Assignment instance = new Assignment();
        Operand expResult = left;
        Operand result = instance.process(left, right, registers);
        assertEquals(expResult, result);
    }

    
}
