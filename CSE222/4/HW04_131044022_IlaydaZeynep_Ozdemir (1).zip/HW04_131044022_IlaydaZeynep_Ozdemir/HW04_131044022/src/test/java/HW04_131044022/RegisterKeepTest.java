/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class RegisterKeepTest {
    
    public RegisterKeepTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of add method, of class RegisterKeep.
     */
    @Test
    public void testAdd() {
        System.out.println("add");
        String regName = "";
        RegisterKeep instance = new RegisterKeep();
        instance.add(regName);
    }

    /**
     * Test of size method, of class RegisterKeep.
     */
    @Test
    public void testSize() {
        System.out.println("size");
        RegisterKeep instance = new RegisterKeep();
        int expResult = 0;
        int result = instance.size();
        assertEquals(expResult, result);
    }

    /**
     * Test of nextRegisterIndex method, of class RegisterKeep.
     */
    @Test
    public void testNextRegisterIndex() {
        System.out.println("nextRegisterIndex");
        RegisterKeep instance = new RegisterKeep();
        int expResult = -1;
        int result = instance.nextRegisterIndex();
        assertEquals(expResult, result);
    }

    /**
     * Test of connect method, of class RegisterKeep.
     */
    @Test
    public void testConnect_Operand_String() {
        System.out.println("connect");
        Operand keep_ = new IntegerNumber();
        String regName = "t0";
        RegisterKeep instance = new RegisterKeep();
        instance.connect(keep_, regName);
    }

    /**
     * Test of connect method, of class RegisterKeep.
     */
    @Test
    public void testConnect_Operand() {
        System.out.println("connect");
        Operand keep_ = new IntegerNumber();
        RegisterKeep instance = new RegisterKeep();
        instance.connect(keep_);
    }

    /**
     * Test of unconnect method, of class RegisterKeep.
     */
    @Test
    public void testUnconnect() {
        System.out.println("unconnect");
        Operand keep_ = new IntegerNumber();
        RegisterKeep instance = new RegisterKeep();
        instance.unconnect(keep_);
    }

    /**
     * Test of listEmptyRegister method, of class RegisterKeep.
     */
    @Test
    public void testListEmptyRegister() {
        System.out.println("listEmptyRegister");
        RegisterKeep instance = new RegisterKeep();
        instance.listEmptyRegister();
    }
    
}
