/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class DivideTest {
    
    public DivideTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of process method, of class Divide.
     */
    @Test
    public void testProcess() throws Exception {
        System.out.println("process");
        Operand left = new IntegerNumber("7");
        Operand right = new IntegerNumber("7");
        RegisterKeep registers = new RegisterKeep();
        Divide instance = new Divide();
        Operand expResult = new ResultOperand("1");
        Operand result = instance.process(left, right, registers);
        assertEquals(expResult, result);
    }
    
}
