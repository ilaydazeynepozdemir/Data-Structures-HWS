/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class PrintTest {
    
    public PrintTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of process method, of class Print.
     */
    @Test
    public void testProcess() {
        System.out.println("process");
        Operand left = new IntegerNumber();
        Operand right =  new IntegerNumber();
        RegisterKeep registers = new RegisterKeep();
        Print instance = new Print();
        Operand expResult = new ResultOperand("1");
        Operand result = instance.process(left, right, registers);
        assertEquals(expResult, result);
    }
    
}
