/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class TakenExpressionsTest {
    
    public TakenExpressionsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of readFile method, of class TakenExpressions.
     */
    @Test
    public void testReadFile() {
        System.out.println("readFile");
        String filename = "";
        TakenExpressions instance = new TakenExpressions();
        instance.readFile(filename);
    }

    /**
     * Test of writePostfix method, of class TakenExpressions.
     */
    @Test
    public void testWritePostfix() {
        System.out.println("writePostfix");
        TakenExpressions instance = new TakenExpressions();
        instance.writePostfix();
        instance.writePostfix();
    }

    /**
     * Test of isMemberVariable method, of class TakenExpressions.
     */
    @Test
    public void testIsMemberVariable() {
        System.out.println("isMemberVariable");
        String thisThing = "a";
        TakenExpressions instance = new TakenExpressions();
        int expResult = -1;
        int result = instance.isMemberVariable(thisThing);
        assertEquals(expResult, result);
    }

    /**
     * Test of getPostfixLines method, of class TakenExpressions.
     */
    @Test
    public void testGetPostfixLines() {
        System.out.println("getPostfixLines");
        TakenExpressions instance = new TakenExpressions();
        List<InfixToPostfix> expResult = new ArrayList<>();
        List<InfixToPostfix> result = instance.getPostfixLines();
        assertEquals(expResult, result);
    }
    
}
