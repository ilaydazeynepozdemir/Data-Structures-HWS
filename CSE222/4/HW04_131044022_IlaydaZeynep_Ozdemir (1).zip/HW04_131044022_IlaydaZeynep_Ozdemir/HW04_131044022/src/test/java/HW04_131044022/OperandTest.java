/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class OperandTest {

    public OperandTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of setRegister_ method, of class Operand.
     */
    @Test
    public void testSetRegister_() {
        System.out.println("setRegister_");
        String given = "";
        Operand instance = new IntegerNumber();
        instance.setRegister_(given);
    }

    /**
     * Test of getRegister_ method, of class Operand.
     */
    @Test
    public void testGetRegister_() {
        System.out.println("getRegister_");
        Operand instance = new IntegerNumber("1");
        String expResult = null;//basta null
        String result = instance.getRegister_();
        assertEquals(expResult, result);
    }

    /**
     * Test of getValue method, of class Operand.
     */
    @Test
    public void testGetValue() {
        System.out.println("getValue");
        Operand instance = new IntegerNumber("0");
        int expResult = 0;
        int result = instance.getValue();
        assertEquals(expResult, result);
    }

    /**
     * Test of setValue method, of class Operand.
     */
    @Test
    public void testSetValue_String() {
        System.out.println("setValue");
        String givenValue = "5";
        Operand instance = new ResultOperand("k");
        instance.setValue(givenValue);
    }

    /**
     * Test of setValue method, of class Operand.
     */
    @Test
    public void testSetValue_int() {
        System.out.println("setValue");
        int given_intValue = 0;
        Operand instance = new ResultOperand("k");;
        instance.setValue(given_intValue);
    }

    /**
     * Test of toString method, of class Operand.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Operand instance = new IntegerNumber("1");
        String expResult = "1";
        String result = instance.toString();
        assertEquals(expResult, result);
    }

    /**
     * Test of equals method, of class Operand.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        Object obj = new IntegerNumber();
        Operand instance = new IntegerNumber();
        boolean expResult = true;
        boolean result = instance.equals(obj);
        assertEquals(expResult, result);
    }

}
