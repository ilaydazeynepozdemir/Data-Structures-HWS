/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class MultiplicationTest {

    public MultiplicationTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of process method, of class Multiplication.
     */
    @Test
    public void testProcess() throws Exception {
        System.out.println("process");
        Operand left = new IntegerNumber("6");
        Operand right = new IntegerNumber("6");
        RegisterKeep registers = new RegisterKeep();
        Multiplication instance = new Multiplication();
        Operand expResult = new ResultOperand("36");
        Operand result = instance.process(left, right, registers);
        assertEquals(expResult, result);
    }

}
