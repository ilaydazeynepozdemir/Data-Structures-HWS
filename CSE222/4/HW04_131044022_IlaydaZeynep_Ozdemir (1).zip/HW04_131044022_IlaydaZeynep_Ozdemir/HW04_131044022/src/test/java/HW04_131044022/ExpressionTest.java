/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.io.FileWriter;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class ExpressionTest {

    public ExpressionTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getMean method, of class Expression.
     */
    @Test
    public void testGetMean() {
        System.out.println("getMean");
        Expression instance = new Minus();
        String expResult = "-";
        String result = instance.getMean();
        assertEquals(expResult, result);
    }

    /**
     * Test of toString method, of class Expression.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Expression instance = new Plus();
        String expResult = "+";
        String result = instance.toString();
        assertEquals(expResult, result);
    }

    /**
     * Test of equals method, of class Expression.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        Object o = new IntegerNumber("7");
        Expression instance = new IntegerNumber("7");
        boolean expResult = true;
        boolean result = instance.equals(o);
        assertEquals(expResult, result);
    }

    /**
     * Test of writeAssembly method, of class Expression.
     */
    @Test
    public void testWriteAssembly() {
        System.out.println("writeAssembly");
        String written = "";
        Expression instance = new Minus();
        instance.writeAssembly(written);
    }

}
