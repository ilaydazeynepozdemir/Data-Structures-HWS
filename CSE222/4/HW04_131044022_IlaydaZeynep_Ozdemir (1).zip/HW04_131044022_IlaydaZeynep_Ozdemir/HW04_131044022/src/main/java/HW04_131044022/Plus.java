/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.io.PrintWriter;
import java.util.List;

/**
 * toplama islemi operatoru commandi add
 *
 * @author ilayda
 */
public class Plus extends MathematicalOperators {

    public Plus() {
        super("+", 1);
        setCommand("add    ");
    }

    /**
     * islemler ypilip assembly e eklemeler yapilir
     *
     * @param left
     * @param right
     * @param registers
     * @return
     * @throws ProcessException
     */
    @Override
    public Operand process(Operand left, Operand right, RegisterKeep registers) throws ProcessException {
        ResultOperand result = new ResultOperand(String.valueOf(left.getValue() + right.getValue()));

        if (left instanceof IntegerNumber) {
            left = new Assignment().process(null, left, registers);
            writeAssembly(getCommand() + "$" + left.getRegister_() + "," + "$" + right.getRegister_());
            registers.unconnect(left);

        }
        if (right instanceof IntegerNumber) {
            new Assignment().process(null, right, registers);
            writeAssembly(getCommand() + "$" + left.getRegister_() + "," + "$" + right.getRegister_());
            registers.unconnect(right);
        }
        //integernumber degilse zatenbunlari tutan bir register var
        if ((!(left instanceof IntegerNumber)) && (!(right instanceof IntegerNumber))) {
            writeAssembly(getCommand() + "$" + left.getRegister_() + "," + "$" + right.getRegister_());
        }
        registers.connect(result);//assignment icinde buna ozel bi sey yapabilirsin
        //writeAssembly(getCommand2() + "$" + result.getRegister_());
        if (right instanceof ResultOperand) {
            registers.unconnect(right);
        }

        if (left instanceof ResultOperand) {
            registers.unconnect(right);
        }
        return result;
    }

}
