/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * expressionlari alir constructorinda postfixe cevirip icindeki postfix_lines
 * iki boyulu arrayine koyar registerlarla expressionlari yonlendirici sinif
 *
 * @author ilayda
 */
public class Process {

    //private TakenExpressions expressions;
    private Stack<Expression> results;

    private List<InfixToPostfix> postfix_lines;

    /*private final String REGISTERS = ;*/
    private RegisterKeep registers = new RegisterKeep();
    /*
     */

    /**
     * Constructor aldigi expressionlari postfixe cevirip kullanacagimiz
     * registerlari ekleriz
     *
     * @param thisExpressions
     */
    public Process(TakenExpressions thisExpressions) {
        // expressions = thisExpressions;
        results = new Stack<>();
        postfix_lines = thisExpressions.getPostfixLines();
        registers.add("t0");
        registers.add("t1");
        registers.add("t2");
        registers.add("t3");
        registers.add("t4");
        registers.add("t5");
        registers.add("t6");
        registers.add("t7");
        registers.add("t8");
        registers.add("a0");
        registers.add("v1");

    }

    /**
     * postfixlines iki boyulu arrayi satir satir postfix ifadeleri tutar posfix
     * halindeki satiri aldigimizda islem yapilir eger elimizdeki operatorse
     * gecici olarak koydugumuz operandlari alip isleme sokariz
     *
     */
    public void makeProcess() {
        Operator oprt = null;
        Operand oprnd1 = null;
        Operand oprnd2 = null;
        int sign = 0;
        try {
            // System.out.println("postfix-> " + postfix_lines);
            for (int i = 0; i < postfix_lines.size(); ++i) {
                for (int j = 0; j < postfix_lines.get(i).getPostfix().size(); ++j) {

                    Expression popExpr = postfix_lines.get(i).getPostfix().get(j);
                    if (popExpr instanceof Operand) {
                        Operand tempOpr = (Operand) popExpr;

                        results.push(tempOpr);//operandsa bir liste atildi sonra cekilecek
                    } else if (popExpr instanceof Operator) {
                        oprt = (Operator) popExpr;
                        if (!(results.isEmpty())) {
                            oprnd1 = (Operand) results.pop();//throw bossa hatali bi eyler var try catch koy unutma cast exception
                        }

                        if (!(results.isEmpty())) {
                            oprnd2 = (Operand) results.pop();
                        }

                        if (oprt != null && (oprnd1 != null && oprnd2 != null)) {
                            try {
                                Operand outputOfprocess = null;
                                outputOfprocess = oprt.process(oprnd2, oprnd1, registers); //stackten ters geliyorlar
                                results.push(outputOfprocess);
                            } catch (ProcessException ex) {
                                System.out.println(ex);
                                return;
                            }
                        }
                    }
                    if (popExpr instanceof IntegerNumber) {
                        IntegerNumber temp = (IntegerNumber) popExpr;
                        int last = 0;

                    }
                }//bir satirlik postfix okundu

            }
        } catch (NullPointerException ex) {
            System.out.println("Null olan bir seylere ulasmaya calisti");
            return;
        }
    }

}
