/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

/**
 * Operand abstract bir class degildir ama bundan tureyen classlar kullanilir
 * abstract olacak bir metodu yoktur
 *
 * @author ilayda
 */
public class Operand extends Expression {

    private int value;
    private String register_;/*biri set edene kadar null*/


    /**
     * consturctor value degerini
     *
     * @param given verilen ifade
     */
    public Operand(String given) {
        super(given);
        setValue(given);
        register_ = null;

    }

    /**
     *
     * register adini set eder
     *
     * @param given
     */
    public void setRegister_(String given) {
        this.register_ = given;
    }

    /**
     * register adini get eder
     *
     * @return
     */
    public String getRegister_() {
        return register_;
    }

    /**
     * int value get eder
     *
     * @return
     */
    public int getValue() {
        return this.value;
    }

    /**
     * eger gelen sey integera parse edilemezse ya da nullsa exception firlar
     * bunlari yakalayip degerlerini 0 yapariz
     *
     * @param givenValue verilen deger
     */
    public void setValue(String givenValue) {//Integersa degeri var ama variablesa basta degeri
        try {
            this.value = Integer.parseInt(givenValue);
        } catch (NullPointerException ex) {
            value = 0;
        } catch (NumberFormatException ex) {
            value = 0;
        }
    }

    /**
     * degerini integer yollayarak set eder
     *
     * @param given_intValue yollanan integer
     */
    public void setValue(int given_intValue) {
        value = given_intValue;
    }

    /**
     * Objecten gelen metod override
     *
     * @return
     */
    @Override
    public String toString() {
        return getMean()/*+"-"+getValue()*/;
    }

    /**
     * Objecten gelen metod override
     *
     * @param obj karsilastirilacak obje
     * @return ayni ise true
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() == obj.getClass()) {
            Operand temp = (Operand) obj;
            return ((this.value == temp.value)
                    && (this.getMean().equals(temp.getMean())));

        } else {
            return false;
        }
    }

}
