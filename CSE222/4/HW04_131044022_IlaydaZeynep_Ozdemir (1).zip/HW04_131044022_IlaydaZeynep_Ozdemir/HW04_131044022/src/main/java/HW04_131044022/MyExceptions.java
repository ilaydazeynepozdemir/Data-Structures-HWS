/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

/**
 *
 * @author ilayda
 */
public class MyExceptions extends Exception{
     private final String  error ;

    public MyExceptions(String nameOfError) {
        error = nameOfError;
    }
     
    @Override
    public String toString() {
        return error;
    }
}
