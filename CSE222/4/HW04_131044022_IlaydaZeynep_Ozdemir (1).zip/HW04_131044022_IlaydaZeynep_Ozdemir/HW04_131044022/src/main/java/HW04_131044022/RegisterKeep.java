/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.util.ArrayList;
import java.util.List;

/**
 * icinde 10 tane register tutan bir veri yapisi "$t0" + "$t1" + "$t2" + "$t3" +
 * "$t4"+ "$t5" + "$t6" + "$t7" + "$t8" + "$a0" + "$v1"
 *
 * @author ilayda
 */
public class RegisterKeep {

    private List<String> names;
    private List<Operand> keeps;
    private boolean isEmpty = true;

    public RegisterKeep() {
        names = new ArrayList();
        keeps = new ArrayList(); //olusurken null
    }

    /**
     * registerlara ekleme yapar ilk eklenmede tuttuklari operandlar null
     *
     * @param regName
     */
    public void add(String regName) {
        names.add(regName);
        keeps.add(null);//basta hepsi 
    }

    /**
     * registerin size'ini verir
     *
     * @return
     */
    public int size() {
        return names.size();
    }

    /**
     * verilen indexteki register adini dondurur
     *
     * @param index bu indexteki register isteniyor
     * @return register adi dondurulur
     */
    public String get(int index) {//adini dondurur
        return names.get(index);
    }

    /**
     * eklenme yapilacak yeni register dondurulur t0-t8 arasi registerlari
     * kullanabilir bu nedenle yanlis index olursa OutOfRegisterLimit exceptioni
     * yollanir ve sonra try catch ile tutup -1 dondurlur
     *
     * @return next index
     */
    public int nextRegisterIndex() {//private aslinda test icin public yaptim
        try {
            for (int i = 0; i < keeps.size(); ++i) {
                if ((keeps.get(i) == null) && (names.get(i) != "a0" && names.get(i) != "v1")) {
                    return i;
                }
            }
            throw new OutOfRegisterLimit();
        } catch (OutOfRegisterLimit ex) {
            return -1;
        }
    }

    /**
     * verilen operand ve verilen isimdeki register arasinda baglanti kurulur
     * register adindan kendi icindeki listeden registeri bulup baglantiyi
     * saglar
     *
     * @param keep_ registeri almak isteyen operand
     * @param regName istenilen register
     */
    public void connect(Operand keep_, String regName) {
        try {
            int index = names.indexOf(regName);
            if (index >= 0 || index < keeps.size()) {
                keeps.set(index, keep_);
            }
            keep_.setRegister_(this.get(index));//baglanti kurdugu operanda da kendi adini yazacak
        } catch (ArrayIndexOutOfBoundsException ex) {
            return;
        }

    }

    /**
     * verilen operand ve siradaki register arasinda baglanti kurulur
     *
     * @param keep_ bu operand register istiyor
     */
    public void connect(Operand keep_) {

        int index = nextRegisterIndex();
        if (index < 0) {
            return;
        }
        keeps.set(index, keep_);
        keep_.setRegister_(this.get(index));//baglanti kurdugu operanda da kendi adini yazacak

    }

    /**
     * gecici bir operandsa register artik onu tutmaz ve o da artik bir
     * registera sahip olmaz
     *
     * @param keep_ baglantisinin koparilmasi gereken operand
     */
    public void unconnect(Operand keep_) {
        for (int i = 0; i < keeps.size(); ++i) {
            if (keeps.get(i) != null) {
                if (keeps.get(i).equals(keep_)) {
                    //System.out.println(keeps.get(i).getRegister_());
                    keep_.setRegister_(null);
                    keeps.set(i, null);
                }
            }
        }
    }

    /**
     * bos registerlari listeler
     */
    public void listEmptyRegister() {
        int index = 0;
        index = nextRegisterIndex();
        if (index == -1) {
            System.out.println("Bos register yok");
        } else {
            System.out.println(names.get(index));
        }

    }

}
