/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.io.PrintWriter;
import java.util.List;

/**
 * abstract bir siniftir predence'a sahiptir
 *
 * @author ilayda
 */
public abstract class Operator extends Expression {

    private int predence;
    private String command;
    private String command2;

    /**
     * constructor
     *
     * @param given verilen operator
     * @param pred oncelik sirasi
     */
    public Operator(String given, int pred) {
        super(given);
        predence = pred;
    }

    /**
     * oncelik set edilir
     *
     * @param given verilen oncelik
     */
    public void setPredence(int given) {
        this.predence = given;
    }

    /**
     * predence
     *
     * @return int
     */
    public int getPredence() {
        return predence;
    }

    public void setCommand(String takeCommand) {
        this.command = takeCommand;
    }


    public String getCommand() {
        return command;
    }


    /**
     * process methodu hem islem yapar hem assembly file'i doldurur
     *
     * @param left sol operand
     * @param right sag operand
     * @param registers registerlar
     * @return operand doner
     * @throws ProcessException bazi durumlarda exception firlatabilir
     */
    abstract public Operand process(Operand left, Operand right, RegisterKeep registers) throws ProcessException;
}
