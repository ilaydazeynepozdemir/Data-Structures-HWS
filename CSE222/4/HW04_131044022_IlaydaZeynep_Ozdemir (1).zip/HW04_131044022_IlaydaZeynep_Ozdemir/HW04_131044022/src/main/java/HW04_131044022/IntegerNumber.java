/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.io.PrintWriter;

/**
 * integer sayilar registerlari gecici
 * @author ilayda
 */
public class IntegerNumber extends Operand{
 
    //register'i gecici olur
    

    public IntegerNumber() {
        super("-");
    }
    public IntegerNumber(String val) {
        super(val);
    }

    
   
    
}
