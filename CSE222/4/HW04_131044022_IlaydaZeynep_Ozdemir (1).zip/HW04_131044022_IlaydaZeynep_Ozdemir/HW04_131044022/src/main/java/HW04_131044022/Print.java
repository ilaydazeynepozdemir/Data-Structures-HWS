/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.io.PrintWriter;
import java.util.List;

/**
 * print operatoru ekranra basar
 *
 * @author ilayda
 */
public class Print extends Operator {

    public Print() {
        super("print", -1);
    }

    @Override
    public Operand process(Operand left, Operand right, RegisterKeep registers) throws ProcessException {

        if (left == null ) {
            writeAssembly("move" + "$" + "a0" + "," + "$" + right.getRegister_());//print
            registers.connect(right, "a0");
            writeAssembly(getCommand() + "$" + "v0" + "," + right.getValue());//print

            return right;
        }

        return new ResultOperand("1");
    }

}
