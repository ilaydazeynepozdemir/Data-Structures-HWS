/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.io.PrintWriter;
import java.util.List;

/**
 * carpma islemi operatoru
 *
 * @author ilayda
 */
public class Multiplication extends MathematicalOperators {

    private final String command2 = "mflo    ";

    /**
     * constructor
     */
    public Multiplication() {
        super("*", 2);
        setCommand("mult    ");
    }

    private String getCommand2() {
        return command2;
    }

    /**
     * islemleri yapip assemblye ekler
     *
     * @param left sol operand
     * @param right sag operand
     * @param registers registerlar
     * @return islem sonucu doer
     * @throws ProcessException
     */
    @Override
    public Operand process(Operand left, Operand right, RegisterKeep registers) throws ProcessException {

        ResultOperand result = new ResultOperand(String.valueOf(left.getValue() * right.getValue()));
        /*System.out.println(right);*/
        if (left instanceof IntegerNumber) {
            left = new Assignment().process(null, left, registers);
            writeAssembly(getCommand() + "$" + left.getRegister_() + "," + "$" + right.getRegister_());
            registers.unconnect(left);

        }
        if (right instanceof IntegerNumber) {
            new Assignment().process(null, right, registers);
            writeAssembly(getCommand() + "$" + left.getRegister_() + "," + "$" + right.getRegister_());
            registers.unconnect(right);
        }
        //integernumber degilse zatenbunlari tutan bir register var
        if ((!(left instanceof IntegerNumber)) && (!(right instanceof IntegerNumber))) {
            writeAssembly(getCommand() + "$" + left.getRegister_() + "," + "$" + right.getRegister_());
        }
        registers.connect(result);//assignment icinde buna ozel bi sey yapabilirsin
        writeAssembly(getCommand2() + "$" + result.getRegister_());
        return result;

    }

}
