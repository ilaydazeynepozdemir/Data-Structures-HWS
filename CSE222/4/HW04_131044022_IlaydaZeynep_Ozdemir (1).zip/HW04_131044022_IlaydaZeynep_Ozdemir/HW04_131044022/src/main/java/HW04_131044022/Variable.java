
package HW04_131044022;

import java.io.PrintWriter;

/**
 *degiskenle registerlari kalici
 * @author ilayda
 */
public class Variable extends Operand {

    //registeri kalici olur


    public Variable(String name) {
        super(name);
    }

    public Variable(String name, String valueOfVar) {
        super(name);
    }

 

}
