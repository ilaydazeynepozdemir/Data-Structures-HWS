/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

/**
 * Assignment expressioninin classi commandi li'dir
 *
 * @author ilayda
 */
public class Assignment extends Operator {

    private final String command2 = "move    ";

    public Assignment() {
        super("=", 0);
        setCommand("li      ");
    }

    private String getCommond2() {
        return command2;
    }

    /**
     * process metodu en karmaşık olan operatordur cunku bir cok islem sonunda
     * yeni bir assignment islemi gerceklestirilmeli
     *
     * @param left isleme sokulacak sol operand variable olmalidir (eger ozel
     * durumlara girmiyorsa exception firlatilir)
     * @param right atanacak operand
     * @param registers
     * @return
     * @throws ProcessException
     */
    @Override
    public Operand process(Operand left, Operand right, RegisterKeep registers) throws ProcessException {
        if (left == null && right instanceof IntegerNumber) {//ozel durum
            //ozel durum bazı fonksiyonlardan cagirilir IntegerNumber olunca li ile reg atansin diye
            //gecici olarak bir registerla baglandti kurulur
            registers.connect(right);
            writeAssembly(getCommand() + "$" + right.getRegister_() + "," + right.getValue());
            //cagirilan fonksiyonda unconnect yapilacak isi bitince
            return right;
        } else if (left == null && right instanceof ResultOperand) {
            //bu da ozel durum 
            registers.connect(right);//sub yaparken
            return right;
        } else if (left instanceof Variable) {//sol taraf variable olmali
            left.setValue(right.getValue());
            if (left instanceof Variable && right instanceof IntegerNumber) {//ilk tanimlanma anlari
                registers.connect(left);//!!!!!!!!!!!
                writeAssembly(getCommand() + "$" + left.getRegister_() + "," + left.getValue());
                //System.out.println(getCommand() + "$" + left.getRegister_() + "," + left.getValue());
            } else if (left instanceof Variable && right instanceof ResultOperand) {
                writeAssembly(getCommond2() + "$" + left.getRegister_() + "," + "$" + right.getRegister_());
                registers.unconnect(right);
               // registers.listEmptyRegister();
                registers.connect(right, left.getRegister_());
            }
            return left;//emin degilim
        }  else {
            throw new ProcessException();

        }

    }

}
