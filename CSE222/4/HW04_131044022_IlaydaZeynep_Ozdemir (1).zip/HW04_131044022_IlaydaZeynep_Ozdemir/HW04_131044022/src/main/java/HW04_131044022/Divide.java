/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

/**
 * bolme islemi operatoru
 *
 * @author ilayda
 */
public class Divide extends MathematicalOperators {

    private final String command2 = "mflo    ";

    public Divide() {
        super("/", 2);
        setCommand("div   ");
    }

    private String getCommand2() {
        return command2;
    }

    /**
     * islemler yapilip assembly filea eklemele yapilr
     *
     * @param left sol operand
     * @param right sag operand
     * @param registers registerlar
     * @return
     * @throws ProcessException
     */
    @Override
    public Operand process(Operand left, Operand right, RegisterKeep registers) throws ProcessException {
        try {
            if (right.getValue() == 0) {
                throw new DivideByZeroException();
            } else {

                ResultOperand result = new ResultOperand(String.valueOf(left.getValue() / right.getValue()));

                if (left instanceof IntegerNumber) {
                    left = new Assignment().process(null, left, registers);
                    writeAssembly(getCommand() + "$" + left.getRegister_() + "," + "$" + right.getRegister_());
                    registers.unconnect(left);

                }
                if (right instanceof IntegerNumber) {
                    new Assignment().process(null, right, registers);
                    writeAssembly(getCommand() + "$" + left.getRegister_() + "," + "$" + right.getRegister_());
                    registers.unconnect(right);
                }
                //integernumber degilse zatenbunlari tutan bir register var
                if ((!(left instanceof IntegerNumber)) && (!(right instanceof IntegerNumber))) {
                    writeAssembly(getCommand() + "$" + left.getRegister_() + "," + "$" + right.getRegister_());
                }
                registers.connect(result);//assignment icinde buna ozel bi sey yapabilirsin
                writeAssembly(getCommand2() + "$" + result.getRegister_());
                return result;
            }

        } catch (DivideByZeroException ex) {
            System.out.println(ex);
            return new ResultOperand(null);//bunu cagiran yerlerde hata verbilir kontrollerini iyi yap!!!
        }
    }

}
