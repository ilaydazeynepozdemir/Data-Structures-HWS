
package HW04_131044022;

import java.io.PrintWriter;

/**
 *islemlerin sonucu bu operand seklinde doner
 * @author ilayda
 */
public class ResultOperand extends Operand{
    /*IntegerNumber result;*/
    public ResultOperand(String res) {
        super(res);
        setValue(res);
        /*result = res;*/
    }
    
    public ResultOperand(int resInt) {
        super(Integer.toString(resInt));
        setValue(resInt);
       /* result = res;*/
    }
   
    
}
