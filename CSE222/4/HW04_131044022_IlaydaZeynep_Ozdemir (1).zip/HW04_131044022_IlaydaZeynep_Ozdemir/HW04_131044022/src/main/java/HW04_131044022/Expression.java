package HW04_131044022;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


/**
 *
 * @author ilayda
 */
abstract public class Expression implements InterfaceExpression {

    private String mean;

    /**
     * constructor
     *
     * @param given
     */
    public Expression(String given) {
        mean = given;
    }

    /**
     * anlamini verir
     *
     * @return expression olusturulurken verilen stringi return eder
     */
    public String getMean() {
        return mean;
    }

    /**
     * Objectden gelen to String override edildi
     *
     * @return classin string hali
     */
    @Override
    public String toString() {
        return mean.toString(); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * append bir dosya aciyoruz yani program ne kadar calisirsa calissin ayni
     * dosyaya yazmaya devam eder Biri tarafindan silinene kadar
     *
     * @param written bu stringi dosyaya yazar
     */
    @Override
    public void writeAssembly(String written) {
        try {
            File temp = new File("output.asm");
            FileWriter outFile = new FileWriter(temp, true);//append
            PrintWriter out = new PrintWriter(outFile);
            out.println(written);
            out.close();
        } catch (IOException ex) {
            System.err.println("Dosya acmada sorun olustu");
        }
    }

}
