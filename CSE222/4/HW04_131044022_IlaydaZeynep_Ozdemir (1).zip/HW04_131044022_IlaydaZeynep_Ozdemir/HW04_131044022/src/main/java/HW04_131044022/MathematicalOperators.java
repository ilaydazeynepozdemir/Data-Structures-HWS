/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;


/**
 *operatorden extend edilir
 * @author ilayda
 */
abstract public class MathematicalOperators extends Operator {

    public MathematicalOperators(String given, int pred) {
        super(given, pred);
    }
    
    @Override
    abstract public Operand process(Operand left, Operand right,RegisterKeep registers) throws ProcessException;
    
}
