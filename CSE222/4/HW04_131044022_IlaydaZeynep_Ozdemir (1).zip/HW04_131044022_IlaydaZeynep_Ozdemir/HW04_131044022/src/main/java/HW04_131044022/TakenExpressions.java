/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * ifadeleri dosyadan okur postfixe cevirip icinde tutar
 *
 * @author ilayda
 */
public class TakenExpressions {

    private List<Variable> variableOfCode;
    private List<Expression> takenExp;
    /**
     * postfixe cevirme classinin arrayini tutma sebebi satir satir cevirme
     * yapsin diye
     */
    private ArrayList<InfixToPostfix> postfixLines;

    private final String OPERATOR = "+-*/=print";

    private static boolean isInteger(String taken) {
        try {
            Integer.parseInt(taken);
        } catch (NumberFormatException ex) {
            return false;
        }
        return true;
    }

    public TakenExpressions() {
        variableOfCode = new ArrayList<Variable>();
        //takenExp = new ArrayList<>();
        postfixLines = new ArrayList<>();
    }

    /**
     * dosyadan okunup expressionin tiplerine gore expression listi doldurulur
     *
     * @param filename
     */
    public void readFile(String filename) {
        try {
            File file = new File(filename);
            BufferedReader bufferRead = null;
            bufferRead = new BufferedReader(new FileReader(file));
            String line = null; //= bufferRead.readLine();
            do {

                takenExp = new ArrayList<>();

                line = bufferRead.readLine();
                int sign = 0;
                if (line != null) {
                    for (int i = 0; i < OPERATOR.length(); ++i) {

                        if (line.indexOf((OPERATOR.charAt(i) + "")) != -1) {
                            ++sign;
                        }
                    }
                    if (line.isEmpty()) {
                        return;
                    }
                    if (sign == 1 && (isMemberVariable(line.charAt(0) + "") == -1)) {

                        int a = 0;
                        for (String temp2 : line.split("= ", 2)) {
                            //System.out.println("var "+(line.charAt(0) + ""));
                            if (a == 1) {
                                Variable added = new Variable((line.charAt(0) + ""));
                                /* System.out.println("added  " + added);*/
                                variableOfCode.add(added);
                                // takenExp.add(added);

                            }
                            ++a;
                        }
                    } else if ((sign == 1 && (isMemberVariable(line.charAt(0) + "") == -1)) && (line.indexOf("print") == -1)) {
                        System.out.println("-------" + line.charAt(0));//degisken olmayan bir seyi gorunce exception firlatmayi hallet
                    }

                    { // variable olarak tanimli olmayan bir sey kullanilirsa almaz
                        for (String temp : line.split(" ", line.length())) {
                            if ("+".equals(temp)) {
                                takenExp.add(new Plus());
                            } else if ("-".equals(temp)) {
                                takenExp.add(new Minus());
                            } else if ("*".equals(temp)) {
                                takenExp.add(new Multiplication());
                            } else if ("/".equals(temp)) {
                                takenExp.add(new Divide());
                            } else if ("=".equals(temp)) {
                                takenExp.add(new Assignment());
                            } else if (temp.indexOf("print", 0) == 0) {
                                takenExp.add(new Print());
                            } else if (isInteger(temp)) {
                                takenExp.add(new IntegerNumber(temp));
                            } else if (isMemberVariable(temp) != -1) {
                                /* System.out.println("->" + variableOfCode.get(isMemberVariable(temp)));*/
                                takenExp.add(variableOfCode.get(isMemberVariable(temp)));
                            }
                        }
                    }
                }

                /* System.out.println("-------->" + takenExp);*/
                InfixToPostfix tempInToPost = new InfixToPostfix(takenExp);

                postfixLines.add(tempInToPost);

            } while (line != null);

            System.out.println("variables--------> " + variableOfCode);

        } catch (FileNotFoundException ex) {

            System.out.println("Dosya bulunamadi");
        } catch (IOException ex) {
            System.out.println("Input dosyasinda sorun var");
        }
    }

    /**
     * postfix halindeki expressionlari dosyaya yazar
     *
     * @return filewriter
     */
    public void writePostfix() {
        try {
            File temp = new File("postfix.txt");
            FileWriter outFile = new FileWriter(temp);
            PrintWriter out = new PrintWriter(outFile);
            for (int i = 0; i < this.postfixLines.size(); ++i) {
                if (!this.postfixLines.get(i).getPostfix().isEmpty()) {
                    out.println(this.postfixLines.get(i).getPostfix().toString());
                }
            }
            out.close();
        } catch (IOException ex) {
            System.out.println("Dosya ile ilgili sorunlar oldu");
            return;//hallet!
        }
    }

    /**
     * eger variablelar icinde varsa index yoksa -1 doner
     *
     * @param thisThing aranana ifade
     * @return integer index
     */
    public int isMemberVariable(String thisThing) {
        if (!variableOfCode.isEmpty()) {
            for (int i = 0; i < variableOfCode.size(); ++i) {
                if (variableOfCode.get(i).getMean().equals(thisThing)) {
                    return i;
                }
            }
            return -1;
        } else {
            return -1;
        }
    }

    public List<InfixToPostfix> getPostfixLines() {
        return postfixLines;
    }

}
