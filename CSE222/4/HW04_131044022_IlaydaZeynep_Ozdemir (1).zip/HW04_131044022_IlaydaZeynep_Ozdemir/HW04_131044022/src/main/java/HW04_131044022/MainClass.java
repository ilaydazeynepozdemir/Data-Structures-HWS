/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.util.ArrayList;

/**
 *
 * @author ilayda
 */
public class MainClass {

    private static final String INPUT = "input.txt";

    public static void main(String[] args) {
        
        ArrayList<Expression> exp = new ArrayList();
        TakenExpressions taken_expr = new TakenExpressions();
        taken_expr.readFile(INPUT);
        taken_expr.writePostfix();
        Process processes = new Process(taken_expr);
        processes.makeProcess();
    }

}
