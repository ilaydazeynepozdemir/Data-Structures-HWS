
package HW04_131044022;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 *Infixten postfixe ceviren class
 * icinde hem infix icin list hem postfix ixin list tutar
 * @author ilayda
 */
public class InfixToPostfix {

    private Stack<Operator> stackOperator;
    private List<Expression> postfix;
    private List<Expression> infix;

    public InfixToPostfix() {
        stackOperator = new Stack<>();
        postfix = new ArrayList<>();
        infix = new ArrayList<>();
    }

    /**
     * aldigi arrayListi direk cevirir kendi icinde
     * @param given_infix 
     */
    public InfixToPostfix(List<Expression> given_infix) {
        stackOperator = new Stack<>();
        postfix = new ArrayList<>();
        infix = (ArrayList<Expression>) given_infix;
        translate();

    }

    @Override
    public String toString() {
        return postfix.toString();
    }

    public List<Expression> getPostfix() {
        return postfix;
    }

    /**
     * class icinde bulunan infix ifadeyi postfix hale getirip postfixleri tutan
     * liste yerlestirri bunu yaparken stack'i yardimci olarak kullanir
     */
    private void translate() {
        for (int i = 0; i < infix.size(); ++i) {
            if (infix.get(i) instanceof Operand) {
                postfix.add(infix.get(i));
            } else if (infix.get(i) instanceof Operator) {
                Operator opt = (Operator) infix.get(i);
                if (this.stackOperator.isEmpty()) {
                    this.stackOperator.push(opt);
                } else {
                    Operator topOpt = stackOperator.peek();
                    if (opt.getPredence() > topOpt.getPredence()) {
                        this.stackOperator.add(opt);
                    } else {
                        while (!this.stackOperator.isEmpty() && opt.getPredence() <= topOpt.getPredence()) {
                            this.stackOperator.pop();
                            this.postfix.add(topOpt);
                            if (!this.stackOperator.empty()) {
                                topOpt = this.stackOperator.peek();
                            }
                        }
                        this.stackOperator.push(opt);
                    }
                }
            }
        }

        while (!stackOperator.isEmpty()) {
            Operator optTemp = stackOperator.pop();
            postfix.add(optTemp);
        }
    }



}
