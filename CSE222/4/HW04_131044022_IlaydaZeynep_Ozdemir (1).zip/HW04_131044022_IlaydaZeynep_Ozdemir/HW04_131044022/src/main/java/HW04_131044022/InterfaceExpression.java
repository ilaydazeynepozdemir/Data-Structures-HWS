/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW04_131044022;

import java.io.FileWriter;

/**
 *
 * @author ilayda
 */
public interface InterfaceExpression {

    /**
     * getmean'i yazmayi zorunlu hale getirdik
     * cunku her expression'in bu methodu olmali
     * ayrica writeAssembly sayesinde expressionlar assembly dosyasina bir seyler yazabilir
     * @return 
     */
    public String getMean();

    /**
     * assembly output.asm dosyasina yazma dosyasi yazilmali
     * @param written
     */
    public void writeAssembly(String written);
}
