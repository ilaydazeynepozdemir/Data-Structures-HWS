/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW06;

/**
 *
 * @author ilayda
 */
public class EmptyTree extends Exception {
    String error;
    public EmptyTree() {
        error = "Hata : Agac olusturulamadigi icin islem yapilamaz";
    }

    @Override
    public String toString() {
        return error;
    }
    
    
}
