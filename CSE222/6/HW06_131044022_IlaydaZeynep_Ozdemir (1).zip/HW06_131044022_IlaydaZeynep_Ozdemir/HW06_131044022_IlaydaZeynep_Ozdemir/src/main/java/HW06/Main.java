/*
 * main classi 
 */
package HW06;

import HW06.HuffmanTree.HuffData;
import java.util.Iterator;

/**
 *
 * @author ilayda
 */
public class Main {

    public static void main(String[] args) {
        BinarySearchTree<Integer> Btree = new BinarySearchTree<>();
        Btree.add(2);
        Btree.add(1);
        Btree.add(12);
        Btree.add(20);
        Btree.add(11);
        Btree.add(0);
        Iterator itr = Btree.getIterator();
        System.out.println("PART1 TEST");
        System.out.println("Tree : "+Btree);
        while (itr.hasNext()) {
            System.out.println(itr.next());
        }
        System.out.println("#########");
        HuffmanTree Htree = new HuffmanTree();

        // Create symbol array
        HuffData[] symbols = {
            new HuffData(186, '_'),
            new HuffData(103, 'e'),
            new HuffData(80, 't'),
            new HuffData(64, 'a'),
            new HuffData(63, 'o'),
            new HuffData(57, 'i'),
            new HuffData(57, 'n'),
            new HuffData(51, 's'),
            new HuffData(48, 'r'),
            new HuffData(47, 'h'),
            new HuffData(32, 'd'),
            new HuffData(32, 'l'),
            new HuffData(23, 'u'),
            new HuffData(22, 'c'),
            new HuffData(21, 'f'),
            new HuffData(20, 'm'),
            new HuffData(18, 'w'),
            new HuffData(16, 'y'),
            new HuffData(15, 'g'),
            new HuffData(15, 'p'),
            new HuffData(13, 'b'),
            new HuffData(8, 'v'),
            new HuffData(5, 'k'),
            new HuffData(1, 'j'),
            new HuffData(1, 'q'),
            new HuffData(1, 'x'),
            new HuffData(1, 'z')
        };

        // Build hufffman tree 
        Htree.buildTree(symbols);

        // Print huffman codes of the symbols
        /*String EncodedSymbolList = Htree.toString();

        // Decode huffman codes to symbıls
        String code = "110000100111111100101000011";
        String decodedCode = Htree.decode(code);
        System.out.println("Code to Message : \n" + code + " : \t" + decodedCode);*/
        System.out.println("PART2 TEST");
        String message = "kal";
        String encoded = Htree.encode(message);
        System.out.println("Encode to Message : " + message + " : " + encoded);

        String message2 = "ekmek_";
        String encoded2 = Htree.encode(message2);
        System.out.println("Encode to Message : " + message2 + " : " + encoded2);

        String message3 = "v";
        String encoded3 = Htree.encode(message3);
        System.out.println("Encode to Message : " + message3 + " : " + encoded3);
        
        String message4 = "metin";
        String encoded4 = Htree.encode(message4);
        System.out.println("Encode to Message : " + message4 + " : " + encoded4);
        System.out.println("########");

    }

}
