/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW06;

import java.io.PrintStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class HuffmanTreeTest {
    
    public HuffmanTreeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("HUFFMAN TREE CLASSI ENCODED TESTI");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("HUFFMAN TREE CLASSI ENCODED TESTI BITTI");
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    /**
     * Test of encode method, of class HuffmanTree.
     */
    @org.junit.Test
    public void testEncode() {
        System.out.println("encode");
        String message = "a";
        HuffmanTree instance = new HuffmanTree();
        String expResult = "";//agac yok cunku
        String result = instance.encode(message);
        assertEquals(expResult, result);
    }
    
}
