/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW06;

import java.util.Iterator;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class BinarySearchTreeTest {

    public BinarySearchTreeTest() {
    }

    @BeforeClass
    public static void setUpClass() {
        System.out.println("BINARY SEARCH CLASSI ITERATOR TESTI");
    }

    @AfterClass
    public static void tearDownClass() {
        
        System.out.println("BINARY SEARCH CLASSI ITERATOR TESTI BITTI");
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getIterator method, of class BinarySearchTree.
     */
    @Test
    public void testGetIterator() {
        System.out.println("getIterator");
        BinarySearchTree instance = new BinarySearchTree<>();
        instance.add(1);
        instance.add(7);
        instance.add(2);
        instance.add(4);
        Integer expResult = 1;
        Integer result = (Integer) instance.getIterator().next();
        assertEquals(expResult, result);
    }

}
