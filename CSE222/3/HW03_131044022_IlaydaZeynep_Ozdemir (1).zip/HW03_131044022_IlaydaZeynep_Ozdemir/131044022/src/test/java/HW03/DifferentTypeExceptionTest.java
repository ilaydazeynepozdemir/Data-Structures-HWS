/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW03;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class DifferentTypeExceptionTest {
    
    public DifferentTypeExceptionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("###DifferentTypeException classinin testi basladi###");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("###DifferentTypeException classinin testi bitti###");
    }
    
    
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * toString metodu testi -DifferentTypeException.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        DifferentTypeException instance = new DifferentTypeException();
        String expResult = "#### Farkli tipte bir liste yolladin ####";
        String result = instance.toString();
        assertEquals(expResult, result);
    }
    
}
