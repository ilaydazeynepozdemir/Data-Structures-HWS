/*
 * Test Interface
 */
package HW03;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class InterfaceSpecListTest extends TestCase {
    
    public InterfaceSpecListTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("####baslangic InterfaceSpecListTest####");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("####bitis InterfaceSpecListTest####");
    }
    
    @Before
    @Override
    public void setUp() {
    }
    
    @After
    @Override
    public void tearDown() {
    }

    /**
     * addAllAtHead methodunun testi
     */
    @Test
    public void testAddAllAtHead() {
        System.out.println("addAllAtHead");
        Collection c = new LinkedList();
        InterfaceSpecList instance = new SpecList();
        Boolean expResult = false; //bos liste bos listeye eklenirse false doner
        Boolean result = instance.addAllAtHead(c);
        assertEquals(expResult, result);
    }

    /**
     * getIntersectList metodu testi
     */
    @Test
    public void testGetIntersectList() {
        System.out.println("getIntersectList");
        Collection c = new SpecList();
        InterfaceSpecList instance = new SpecList();
        List expResult = new SpecList();
        List result = instance.getIntersectList(c);
        assertEquals(expResult, result);
    }

    /**
     *  sortList metodu testi
     */
    @Test
    public void testSortList_0args() {
        System.out.println("sortList");
        InterfaceSpecList instance = new SpecList();
        List expResult = new SpecList();
        List result = instance.sortList();
        assertEquals(expResult, result);
    }

    /**
     *  sortList metodu testi
     */
    @Test
    public void testSortList_int() {
        System.out.println("sortList");
        int sign = 0;
        InterfaceSpecList instance = new SpecList();
        List expResult = new SpecList();
        List result = instance.sortList(sign);
        assertEquals(expResult, result);
    }




    
}
