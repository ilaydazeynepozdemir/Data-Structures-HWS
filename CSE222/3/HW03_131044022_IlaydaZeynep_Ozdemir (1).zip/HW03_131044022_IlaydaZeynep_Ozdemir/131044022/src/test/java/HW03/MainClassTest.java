/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW03;

import junit.framework.TestCase;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class MainClassTest extends TestCase{
    
    public MainClassTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("###Main Test###");
    }
    
    @AfterClass
    public static void tearDownClass() {
         System.out.println("###Main Test Bitimi###");
    }
    
    @Before
    @Override
    public void setUp() {
    }
    
    @After
    @Override
    public void tearDown() {
    }

    /**
     * main testi
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        MainClass.main(args);
    }

    /**
     * integer testi metodunun testi
     */
    @Test
    public void testTestInteger() {
        System.out.println("testInteger");
        MainClass.testInteger();
    }

    /**
     * string testi metodunun testi
     */
    @Test
    public void testTestString() {
        System.out.println("testString");
        MainClass.testString();
    }

    /**
     * long testi metodunun testi
     */
    @Test
    public void testTestLong() {
        System.out.println("testLong");
        MainClass.testLong();
    }

    /**
     * ekrana bilgi basan fonksiyonun testi
     */
    @Test
    public void testReport() {
        System.out.println("report");
        SpecList spec1 = null;
        SpecList spec2 = null;
        MainClass.report(spec1, spec2);
    }

    /**
     * double testi metodunun testi
     */
    @Test
    public void testTestDouble() {
        System.out.println("testDouble");
        MainClass.testDouble();
    }
    
}
