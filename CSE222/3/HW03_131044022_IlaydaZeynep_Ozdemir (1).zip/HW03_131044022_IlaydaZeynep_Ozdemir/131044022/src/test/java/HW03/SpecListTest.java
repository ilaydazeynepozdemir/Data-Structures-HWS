/*
 * Test
 */
package HW03;

import java.util.Collection;
import java.util.List;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author ilayda
 */
public class SpecListTest extends TestCase{

    public SpecListTest() {
    }

    @BeforeClass
    public static void setUpClass() {
        System.out.println("###Speclist classinin testi basladi###");
    }

    @AfterClass
    public static void tearDownClass() {
        System.out.println("###Speclist classinin testi bitti###");
    }

    /**
     *
     */
    @Before
    @Override
    public void setUp() {
    }

    @After
    @Override
    public void tearDown() {
    }

    /**
     * addAllAtHead metodu testi
     */
    @Test
    public void testAddAllAtHead() {
        System.out.println("addAllAtHead");
        Collection given = new SpecList();
        SpecList instance = new SpecList();
        Boolean expResult = false;
        Boolean result = instance.addAllAtHead(given);
        assertEquals(expResult, result);
    }

    /**
     *getIntersectList metodu testi
     */
    @Test
    public void testGetIntersectList() {
        System.out.println("getIntersectList");
        Collection given = new SpecList();
        SpecList instance = new SpecList();
        List expResult = new SpecList();
        List result = instance.getIntersectList(given);
        assertEquals(expResult, result);
    }

    /**
     * sortList metodu testi
     */
    @Test
    public void testSortList_0args() {
        System.out.println("sortList");
        SpecList instance = new SpecList();
        instance.add(7);
        instance.add(5);
        List expResult = new SpecList();
        expResult.add(5);
        expResult.add(7);
        List result = instance.sortList();
        assertEquals(expResult,result);
    }

    /**
     * sortList metodu testi
     */
    @Test
    public void testSortList_int() {
        System.out.println("sortList");
        int sign = 0;
        int sign2 = 1;
        SpecList instance = new SpecList();
        instance.add(5);
        instance.add(7);
        //birden farkli sayilarda buyukten kucuge
        List expResult1 = new SpecList();
        expResult1.add(7);
        expResult1.add(5);
        List result1 = instance.sortList(sign);//buyukten kucuge
        assertEquals(expResult1, result1);
       //1 yollarsak kucukten buyuge
        List expResult2 = new SpecList();
        expResult2.add(5);
        expResult2.add(7);
        List result2 = instance.sortList(sign2);//kucukten buyuge
        assertEquals(expResult2, result2);
    }

}
