/*
 * Main
 */
package HW03;

import java.util.List;

/**
 *Main
 * @author ilayda
 */
public class MainClass {

    public static void main(String[] args) {
        testInteger();
        testLong();
        testDouble();
        testString();
    }
/**
 * fonksiyonlari speclistleri icin cagirip ekrana basar
 * @param spec1 ilk gonderilen speclist
 * @param spec2 ikinci gonderilen speclist
 */
    public static void report(SpecList spec1, SpecList spec2) {
        try {
            System.out.printf("Spec1 listesi = %s\n", spec1);
            System.out.printf("Spec2 listesi  = %s\n", spec2);
            System.out.printf("Spec1 ve Spec2 kesisim listesi = %s\n", spec1.getIntersectList(spec2));
            System.out.println("");
            System.out.printf("Spec1 Listesinin siralanmis kucukten buyuge hali %s\n", spec1.sortList());
            System.out.printf("Spec1 Listesinin siralanmis buyukten kucuge hali %s\n", spec1.sortList(9));
            System.out.println("");
            System.out.printf("Spec2 Listesinin siralanmis kucukten buyuge hali %s\n", spec2.sortList());
            System.out.printf("Spec2 Listesinin siralanmis buyukten kucuge hali %s\n", spec2.sortList(5));
            System.out.println("");
            System.out.println("Spec2 listesi basina Spec1 eklenir");
            spec2.addAllAtHead(spec1);
            System.out.printf("Yeni Spec2 Listesi %s\n", spec2);
            System.out.println("");
            System.out.printf("Yeni Spec2 Listesinin siralanmis kucukten buyuge hali %s\n", spec2.sortList());
        } catch (Exception ex) {
            System.err.println("Beklenmeyen bir sorun olustu");
        }
        System.out.println("\n**************************************************");
        
    }
/**
 * fonksiyonlari integer icin test eder
 */
    public static void testInteger() {
        System.out.println("\n||||||  INTEGER TESTI  ||||||");
        SpecList spec1 = new SpecList();
        SpecList spec2 = new SpecList();
        spec1.add(1);
        spec1.add(5);
        spec1.add(3);
        spec1.add(-78);
        //
        spec2.add(3);
        spec2.add(3);
        spec2.add(2);
        spec2.add(9);
        spec2.add(6);
        spec2.add(5);
        spec2.add(10);
        spec2.add(7);
        spec2.add(11);
        spec2.add(4);
        spec2.add(12);
        spec2.add(8);
        //
        report(spec1, spec2);
        report(null, null);

    }
/**
 * fonksiyonlari string icin test eder
 */
    public static void testString() {
        System.out.println("\n||||||  STRING TESTI  ||||||");
        SpecList<String> spec1 = new SpecList<>();
        SpecList<String> spec2 = new SpecList<>();//
        //
        spec1.add("il");
        spec1.add("il");
        //
        spec2.add("al");
        spec2.add("il");
        spec2.add("ul");
        //
        report(spec1, spec2);
    }
/**
 * fonksiyonlari double icin test eder
 */
    public static void testDouble() {
        System.out.println("\n||||||  DOUBLE TESTI  ||||||");
        SpecList spec1 = new SpecList();
        SpecList spec2 = new SpecList();
        //
        spec1.add(1.3);
        spec1.add(5.1);
        spec1.add(3.8);
        spec1.add(7.8);
        //
        spec2.add(3.1);
        spec2.add(3.2);
        spec2.add(0.2);
        spec2.add(0.9);
        spec2.add(0.06);
        spec2.add(0.5);
        spec2.add(1.0);
        spec2.add(7.5);
        spec2.add(1.01);
        spec2.add(4.0);
        spec2.add(1.2);
        spec2.add(0.8);
        //
        report(spec1, spec2);
    }
/**
 * fonksiyonlari long icin test eder
 */
    public static void testLong() {
        System.out.println("\n||||||  LONG TESTI  ||||||");
        SpecList<Long> spec1 = new SpecList<>();
        SpecList<Long> spec2 = new SpecList<>();
        //
        spec1.add(12345678910L);
        spec1.add(22345678910L);
        spec1.add(322345678910L);
        spec1.add(722345678910L);
        //
        spec2.add(322345678910L);
        spec2.add(322345678910L);
        spec2.add(222345678910L);
        spec2.add(922345678910L);
        spec2.add(622345678910L);
        spec2.add(12345678910L);
        spec2.add(22345678910L);
        //
        report(spec1, spec2);

    }
}
