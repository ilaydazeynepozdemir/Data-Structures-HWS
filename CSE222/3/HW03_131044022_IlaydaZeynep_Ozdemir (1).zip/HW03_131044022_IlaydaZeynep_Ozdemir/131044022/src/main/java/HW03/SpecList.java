/**
 * Class 
 */
package HW03;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * JavaLinkedList'inden extend olur ve InterfaceSpeclistini implement eder
 *
 * @author ilayda
 * @param <E> Comparable bir turden SpecList olusabilir
 */
public class SpecList<E extends Comparable<E>> extends LinkedList<E> implements InterfaceSpecList<E> {

    /**
     * no parameter constructor
     */
    public SpecList() {
        super();
    }

    /**
     * constructor
     *
     * @param given verilen liste ile olusur
     */
    public SpecList(List given) {
        super(given);
    }

    /**
     * Kesisimlerini bulurken eger kesisim listi icinde varsa eklemez disaridan
     * ulasilamaz sadece Speclistten extend olanlar ulasir
     *
     * @param added eklenecek eleman
     * @return eklenirse true doner,eklenmezse yani zaten varsa false
     */
    private boolean addInsert(E added) {
        try {
            for (int i = 0; i < this.size(); ++i) {
                if (added.equals(this.get(i))) {
                    return false;
                }
            }
            return this.add(added);
        } catch (NullPointerException ex) {
            return false;
        }
    }

    /**
     * karsilastirma sonucu gerekirse swap islemini gerceklestirir
     * gonderilen index ve ondan bir sonraki arasinda
     * @param i swap yapmasi gereken index(i ve i+1 arasinda ) 
     * @param swap swap yapilirsa true yapilip geri dondurulur yapilmazsa alindigi gibi geri doner
     * @param sign karsilastirma sartini belirler
     * @return alinan swap parametresini dondurur
     */
    private boolean swap_ForSpecListElements(int i, boolean swap, int sign) {
        if (this.get(i).compareTo(this.get(i + 1)) == sign) {
            E temp = (E) this.get(i);//secilen
            this.set(i, this.get(i + 1));
            this.set(i + 1, temp);
            swap = true;
        }
        return swap;
    }

    /**
     *
     * alinan collectiondaki her seyi cagirilan speclistin basina ekler
     *
     * @param given alinan liste
     * @return Boolean dondurur eklenirse true
     */
    @Override
    public Boolean addAllAtHead(Collection<? extends E> given) {
        try {
            return this.addAll(0, given);
        } catch (Exception ex) {
            System.err.println("#### Eklemede hatalar olustu ####");
            return false;
        }
    }

    /**
     * cagirilan ve parametre olarak verilen listelerin kesisimlerini bulur yeni
     * bir speclist olusturur ve bunu dondurur
     *
     * @param given kesisimine bakilacak collection
     * @return Kesisim listesini doner
     */
    @Override
    public List<E> getIntersectList(Collection<? extends E> given) {
        
        SpecList returnList = new SpecList();
        try {
            if (given instanceof List) {//collectiondan turemis ama listten turememis bir sey olabilir
               
                List temp = (List) given;
                for (int i = 0; i < this.size(); ++i) {
                    for (int j = 0; j < temp.size(); ++j) {
                        if (this.get(i).getClass() == temp.get(j).getClass()) {
                            if (this.get(i).equals(temp.get(j))) {
                                returnList.addInsert((Comparable) temp.get(j));
                            }
                        } else {
                            //farkli bir tipte liste yollanirsa hata firlatilip mesaj verir
                            throw new DifferentTypeException();
                        }
                    }
                }
            } else {
                throw new ClassCastException();
            }
            return returnList;
        } catch (NullPointerException ex) {
            System.err.println("#### Olusturulmadan yollanan bir seyler var ####");
            return returnList;
        } catch (ClassCastException ex) {
            System.out.println("#### Beklenmeyen bir sinif  ####");
            return returnList;
        } catch (DifferentTypeException ex) {
            System.out.printf(" %s \n", ex.toString());
            return returnList;
        }

    }

    /**
     * parametre almayan sortList methodu kucukten buyuge siralar
     *
     * @return siralanmis Speclist listesi doner
     */
    @Override
    public List<E> sortList() {
        return sortList(1);
    }

    /**
     * integer parametre alan sortList methodu buyukten kucuge siralar Ama eger
     * parametre 1'se kucukten buyuge siralar
     *
     * @param sign 1'se kucukten buyuge diger sayilarda buyukten kucuge
     * siralanmasini saglar
     * @return siralanmis Speclist listesi doner
     */
    @Override
    public List<E> sortList(int sign) {//decreasing_or_increasing
        if (this.isEmpty()) {
            return this;//bossa direk kendisini dondurur
        }
        if (sign == 1); else if (sign != -1) {
            sign = -1;
        }
        SpecList returnList = new SpecList();
        try {
            boolean swap = false;
            for (int i = 0; i < this.size(); ++i) {
                returnList.add(this.get(i));
            }

            do {
                if (returnList.size() == 2) {//referans oldugu icin swap fonksiyonu 
                    swap = returnList.swap_ForSpecListElements(0, swap, sign);
                    return returnList;
                }
                for (int i = 0; i < returnList.size() - 2; ++i) {
                    swap = returnList.swap_ForSpecListElements(i, swap, sign);
                }
                if (swap == false) {
                    return returnList;
                } else {
                    swap = false;
                }
                for (int i = returnList.size() - 2; i >= 0; --i) {
                    swap = returnList.swap_ForSpecListElements(i, swap, sign);
                }
            } while (swap);
            return returnList;
        } catch (NullPointerException ex) {
            System.err.println("#### Olusturulmadan yollanan bir seyler var ####");
            return returnList;
        } catch (Exception ex) {
            System.err.println("#### Bir seyler ters gitti! ####");
            return returnList;
        }

    }

}
