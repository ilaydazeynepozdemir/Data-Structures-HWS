/*
 *Interface
 */
package HW03;

import java.util.Collection;
import java.util.List;

/**
 *
 * Speclistin interface'idir. Bu interface implement edilirken
 * addAllAtHead,getIntersectList,sortList fonksiyonlarini yazmak zorunlu olur
 *
 * @author ilayda
 * @param <E> Comparable olmalidir (CompareTo metodu icin)
 */
public interface InterfaceSpecList<E extends Comparable<E>> {

    /**
     * verilen liste basa eklenir
     *
     * @param c eklenecek collection
     * @return eklenebilirse true doner
     */
    Boolean addAllAtHead(Collection<? extends E> c);

    /**
     * Listelerin kesisim listeleri bulunur
     *
     * @param c kesisim aranacak parametre liste
     * @return olusturulan kesisim listesi return edilir
     */
    List<E> getIntersectList(Collection<? extends E> c);

    /**
     * kucukten buyuge siralar
     *
     * @return siralanmis listeyi dondurur
     */
    List<E> sortList();

    /**
     * 1 yollanirsa kucukten buyuge, -1 veya baska bir sayi yollanirsa buyukten
     * kucuge siralar
     *
     * @param sign kucukten buyuge mi buyukten kucuge mi anlamak icin
     * @return siralanan liste dondurulur
     */
    List<E> sortList(int sign);
}
