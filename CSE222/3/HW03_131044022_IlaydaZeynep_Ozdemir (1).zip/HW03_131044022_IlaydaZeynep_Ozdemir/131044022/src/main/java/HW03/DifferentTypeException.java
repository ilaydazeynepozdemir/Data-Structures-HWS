/*
 *Exception classi
 */
package HW03;

/**
 *Farkli tiplarde seyler yollandiginda firlatilir
 * @author ilayda
 */
public class DifferentTypeException extends Exception {

    public DifferentTypeException() {
        super("#### Farkli tipte bir liste yolladin ####");
    }

    /**
     * exceptioni ekrana basarken %s ile rahatlikla basilsin diye
     *
     * @return getmessage i return eder
     */
    @Override
    public String toString() {
        return super.getMessage();
    }

}
