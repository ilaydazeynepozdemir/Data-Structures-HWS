package HW07.DataStructures;

import HW07.part1.Customer;
import java.util.AbstractCollection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * priority queue (without using any function that is defined in java
 * libraries.)
 * 
 * enqueue method : offer
 * dequeue method : poll
 *
 * @author ilayda
 * @param <E>
 */
public class myPriorityQueue<E> extends AbstractCollection<E> implements Interface_PriorityQueue {

    private MyArrayList<E> array;

    Comparator comp = null;

    public myPriorityQueue() {
        array = new MyArrayList<>();
    }

    /**
     *
     */
    public myPriorityQueue(Comparator given_comp) {
        array = new MyArrayList<>();

        comp = given_comp;
    }

    private int compare(E left, E right) {
        if (comp != null) {
            return comp.compare(left, right);
        } else {
            return ((Comparable<E>) left).compareTo(right);
        }
    }

    public void swap(int parent, int child) {
        E temp = array.get(parent);
        array.set(parent, array.get(child));
        array.set(child, temp);
    }

    /**
     * elemani queue icindeki uygun yere ekler (enqueue)
     *
     * @param item eklenecek
     * @return true
     */
    @Override
    public boolean offer(Object item) {
        array.add((E) item);
        int child = array.size() - 1;
        int parent = (child - 1) / 2;
        while (parent >= 0 && compare(array.get(parent), array.get(child)) > 0) {
            swap(parent, child);
            child = parent;
            parent = (child - 1) / 2;
        }
        return true;
    }

    /**
     * en oncelikli elemani dondurur yoksa null dondurur
     *
     * @return en oncelikli eleman
     */
    @Override
    public E peek() {
        if (isEmpty()) {
            return null;
        } else {
            return array.get(0);
        }
    }

    /**
     * en oncelikli elemani dondurur yoksa exception firlatir
     *
     * @throws NoSuchElementException
     * @return en oncelikli eleman
     */
    @Override
    public E element() {
        E result = peek();
        if (result == null) {
            throw new NoSuchElementException();
        } else {
            return result;
        }
    }

    /**
     * en ustteki elemani dondurur ve siler eleman yoksa null dondurur.(
     * dequeue)
     *
     * @return en oncelikli eleman
     */
    @Override
    public E poll() {

        boolean sign = true;
        if (isEmpty()) {
            return null;
        }
        E deleted = array.get(0);
        if (size() == 1) {
            array.remove(0);
            return deleted;
        }
        array.set(0, array.remove(array.size() - 1));
        int parent = 0;
        while (true) {
            int leftC = 2 * parent + 1;
            if (leftC >= size()) {
                break;
            }
            int rightC = leftC + 1;
            int minC = leftC;
            if (rightC < size() && compare(array.get(leftC), array.get(rightC)) > 0) {
                minC = rightC;
            }
            if (compare(array.get(parent), array.get(minC)) > 0) {
                swap(parent, minC);
                parent = minC;
            } else {
                break;
            }
        }
        return deleted;
    }

    /**
     * en ustteki elemani dondurur ve siler eleman yoksa exceprtion firlatir
     *
     * @throws NoSuchElementException
     * @return en oncelikli eleman
     */
    @Override
    public E remove() {
        E result = poll();
        if (result == null) {
            throw new NoSuchElementException();
        } else {
            return result;
        }
    }

    @Override
    public int size() {
        return array.size();
    }

    /**
     * private inner class
     */
    private class Iterator_PriorityQ implements Iterator {

        @Override
        public boolean hasNext() {
            if (array.size() >= 1) {
                return true;
            } else {
                return false;
            }
        }

        @Override
        public Object next() {
            return array.get(1);
        }

    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator_PriorityQ();
    }

    /**
     * queue'yu string hale getirir
     *
     * @return
     */
    @Override
    public String toString() {
        String buf = "";
        for (int i = 0; i < size(); ++i) {
            buf += (" " + array.get(i));
        }
        return buf;

    }

}
