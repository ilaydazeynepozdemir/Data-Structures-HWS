/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;

import static java.lang.Math.random;

/**
 * carddan extend olur
 *
 * @author ilayda
 */
public class StudentCard extends Card {

    public StudentCard(int givenBarcode) {
        super();
        setBarcode(givenBarcode);
    }
    
    

    /**
     * 1000 ile 5000 arasinda olmasini kontrol eder
     *
     * @param Barcode_
     */

    public void setBarcode(int Barcode_) {
        try {
            if (1000 <= Barcode_ && Barcode <= 5000) {
                this.Barcode = Barcode_ ;
            } else {
                throw new InvalidBarcodeException();
            }
        } catch (InvalidBarcodeException ex) {
            System.out.println(ex);
        }
    }

    /**
     * 1000 5000 arasindaki en buyuk asal sayiyla carpilarak bir hashcode
     * uretiir
     *
     * @return
     */
    @Override
    public int hashCode() {
        return (getBarcode() * 4999);
    }

}
