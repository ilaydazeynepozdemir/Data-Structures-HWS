/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.DataStructures;

/**
 * Interface
 *
 * @author ilayda
 * @param <E>
 */
public interface Interface_PriorityQueue<E> {

    /**
     * en oncelikli elemani dondurur yoksa null dondurur
     *
     * @return en oncelikli eleman
     */
    public E peek();

    /**
     * en oncelikli elemani dondurur yoksa exception firlatir
     *
     * @throws NoSuchElementException
     * @return en oncelikli eleman
     */
    public E element();

    /**
     * en ustteki elemani dondurur ve siler eleman yoksa null dondurur
     *
     * @return en oncelikli eleman
     */
    public E poll();

    /**
     * en ustteki elemani dondurur ve siler eleman yoksa exceprtion firlatir
     *
     * @throws NoSuchElementException
     * @return en oncelikli eleman
     */
    public E remove();

    /**
     * elemani queue icindeki uygun yere ekler
     *
     * @param item eklenecek
     * @return true
     */
    public boolean offer(E item);

    /**
     * queue'yu string hale getirir
     *
     * @return
     */
    @Override
    public String toString();

}
