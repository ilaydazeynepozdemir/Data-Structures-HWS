/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part1;

/**
 *
 * @author ilayda
 */
public interface Interface_Simulation<E> {

    /**
     * simulasyonu baslatir,calistirir
     *
     * @return baslatamazsa false doner
     */
    public boolean startSimulation();

    /**
     * her dosyaya ozgu bir method oldugu icin gerekliyse override edilmeli
     * @param i bu satiri okur
     * @return okudugu satiri E tipine donusturup return eder
     */
    public E readThisLine(int i);
}
