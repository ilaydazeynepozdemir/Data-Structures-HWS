package HW07.part2;

/**
 * insanin adi ve soyadi vardir
 *
 * @author ilayda
 */
abstract public class Person {

    private int price;
    private String Name;
    private String Surname;
    private int IDnumber;

    public Person(String Name, String Surname) {
        this.Name = Name;
        this.Surname = Surname;
        IDnumber = 0;
    }

    public void setIDnumber(int ID) {
        this.IDnumber = ID;
    }

    public int getIDnumber() {
        return IDnumber;
    }
    

    public void setName(String Name_) {
        this.Name = Name_;
    }

    public void setSurname(String Surname_) {
        this.Surname = Surname_;
    }

    public void setPrice(int price_) {
        this.price = price_;
    }

    public int getPrice() {
        return price;
    }

    public String getName() {
        return Name;
    }

    public String getSurname() {
        return Surname;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Person other = (Person) obj;
        if (this.getName().equals(other.getName())
                && this.getSurname().equals(other.getSurname())) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return Name + " " + Surname;
    }

}
