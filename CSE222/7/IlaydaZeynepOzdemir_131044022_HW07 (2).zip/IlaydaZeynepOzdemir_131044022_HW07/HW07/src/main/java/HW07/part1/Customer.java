/*part1*/
package HW07.part1;

import java.sql.Time;
import java.util.Comparator;

/**
 * Customer: serviceTime , cutomerType , arrivalTime ,wait
 *
 * @author ilayda
 */
public class Customer implements Comparator {

    private int serviceTime;
    private String customerType;
    private Time arrivalTime;
    private int waitInQueue;

    /*constructor*/
    public Customer() {
        waitInQueue = 0;
        arrivalTime = new Time(0);
        customerType = null;
        serviceTime = 0;
    }

    public Customer(String type) {
        waitInQueue = 0;
        arrivalTime = new Time(0);
        customerType = type;
        serviceTime = 0;
    }

    /**
     * customerin queue icindeki bekleme dakikasini dondurur
     *
     * @param timeOfNow o anki sistem zamanini alir
     */
    public void setWaitInQueue(final Time timeOfNow) {
        int process_min = timeOfNow.getHours() * 60
                + timeOfNow.getMinutes() + timeOfNow.getSeconds() / 60;
        int arrival_min = arrivalTime.getHours() * 60 + arrivalTime.getMinutes()
                + arrivalTime.getSeconds() / 60;

        waitInQueue = process_min - arrival_min;
        if (waitInQueue < 0) {
            waitInQueue = 0;
        }
    }

    public int getWaitInQueue() {
        return waitInQueue;
    }

    public void setArrivalTime(Time arrivalTime_) {
        this.arrivalTime = arrivalTime_;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType_) {
        this.customerType = customerType_;
    }

    public int getServiceTime() {
        return serviceTime;
    }

    public Time getArrivalTime() {
        return (Time) arrivalTime.clone();
    }

    public void setServiceTime(int serviceTime_) {
        this.serviceTime = serviceTime_;
    }

    /**
     * iki customerin esitliklerini kontrol eder
     *
     * @param obj esitligine bakilacak olan
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)//referans karsilastirmasi
        {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj.getClass().equals(this.getClass())) {
            Customer other = (Customer) obj;
            if ((this.getArrivalTime().equals(other.getArrivalTime())
                    && this.getServiceTime() == (other.getServiceTime()))
                    && this.getCustomerType().equals(other.getCustomerType())) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * iki customeri karsilastirir compareleri ters yazildi 1>2>3 ama
     * comparatore gore 3 buyuk. cunku yazdigim priorityqueue kucuk olana oncelik
     * taniyor esitse 0 ilki customer1 ise -1 ilki customer2 ikincisi customer3
     * ise 1 dondurur diger tum durumlarda 1 dondurur
     *
     * @param obj1
     * @param obj2
     * @return
     */
    @Override
    public int compare(Object obj1, Object obj2) {
        if (obj1 != null && obj2 != null) {
            if (obj1.getClass().equals(this.getClass()) && obj2.getClass().equals(this.getClass())) {
                Customer cus1 = (Customer) obj1;
                Customer cus2 = (Customer) obj2;
                if (cus1.getCustomerType().equals(cus2.getCustomerType())) {
                    return 0;
                } else if (cus1.getCustomerType().equals("1")) {
                    return -1;
                } else if (cus1.getCustomerType().equals("2") && cus2.getCustomerType().equals("3")) {
                    return -1;
                } else {
                    return 1;
                }
            } else {
                throw new ClassCastException();
            }
        } else {
            throw new NullPointerException();
        }
    }

    @Override
    public String toString() {
        return "{arrival:" + arrivalTime + " service time:"
                + serviceTime + " Customer" + customerType + "}";
    }

}
