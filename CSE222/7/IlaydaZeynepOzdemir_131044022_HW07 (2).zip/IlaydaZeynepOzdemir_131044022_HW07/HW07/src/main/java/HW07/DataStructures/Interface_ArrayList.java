/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.DataStructures;

/**
 *
 * @author ilayda
 */
public interface Interface_ArrayList<E> {

    public int size() ;
    public E get(int index);

    public E set(int index, E newValue);
/**
 * 
 * @param target
 * @return 
 */
    public int indexOf(E target);

    /**
     * array boyutunu iki katina cikarir
     */
    public void resize();

    /**
     * arrayi siler
     */
    public void clear() ;

    /**
     * verilen indexteki elemani siler
     *
     * @param index bu indextekini
     * @return sildigi elemani doner
     */
    public E remove(int index) ;

    /**
     * elemani arraye ekler size'i arttirir
     *
     * @param item eklenecek eleman
     * @return true doner
     */
    public boolean add(E item) ;

    /**
     * arrayi stringe cevirir
     *
     * @return arrayin string hali
     */
    public String toString() ;
}
