package HW07.DataStructures;

/**
 * arrayList classim
 *
 * @author ilayda
 * @param <E>
 */
public class MyArrayList<E> {

    private E[] list;
    private int indexOfArray;

    public MyArrayList() {
        list = (E[]) new Object[1];
        indexOfArray = 0;
    }

    /**
     * array sizeini return eder
     *
     * @return size
     */
    public int size() {
        return indexOfArray;
    }

    /**
     * istenilen indexteki elemani dondurur
     *
     * @param index verilen index
     * @return indexteki eleman
     */
    public E get(int index) {
        if ((index > list.length - 1) || (index < 0)) {
            throw new ArrayIndexOutOfBoundsException(index);
        } else {
            return list[index];
        }
    }

    /**
     * verilen indexe verilen elemani set eder eski elemani return eder
     *
     * @param index elemanin set edilemsi istenen index
     * @param newValue eklenecek eleman
     * @return eski eleman
     */
    public E set(int index, E newValue) {
        if ((index > list.length - 1) || (index < 0)) {
            throw new ArrayIndexOutOfBoundsException(index);
        }

        E oldValue = list[index];
        list[index] = newValue;
        return oldValue;
    }

    /**
     * verilen hedefin indexini return eder
     *
     * @param target aranan eleman
     * @return hedefin indexi
     */
    public int indexOf(E target) {
        int index = -1;

        for (int i = 0; i < list.length; i++) {
            if (list[i].equals(target)) {
                index = i;
            }
        }
        return index;
    }

    /**
     * array boyutunu iki katina cikarir
     */
    public void resize() {
        E[] newarray = (E[]) new Object[list.length * 2];

        for (int i = 0; i < indexOfArray; i++) {
            newarray[i] = list[i];
        }
        list = newarray;

        //list = Arrays.copyOf(list, list.length * 2);
    }

    /**
     * arrayi siler
     */
    public void clear() {
        list = null;
        indexOfArray = 0;
    }

    /**
     * verilen indexteki elemani siler
     *
     * @param index bu indextekini
     * @return sildigi elemani doner
     */
    public E remove(int index) {
        if ((index >= indexOfArray) || (index < 0)) {
            throw new ArrayIndexOutOfBoundsException(index);
        }

        E temp = list[index];
        for (int i = index; i < indexOfArray - 1; i++) {
            list[i] = list[i + 1];
        }
        indexOfArray--;
        return temp;
    }

    /**
     * elemani arraye ekler size'i arttirir
     *
     * @param item eklenecek eleman
     * @return true doner
     */
    public boolean add(E item) {
        if (indexOfArray == list.length) {
            resize();
        }

        list[indexOfArray] = item;
        indexOfArray++;
        return true;
    }

    /**
     * arrayi stringe cevirir
     *
     * @return arrayin string hali
     */
    public String toString() {
        String result = null;
        result += "{";
        for (int i = 0; i < indexOfArray; i++) {
            if (i != indexOfArray - 1) {
                result += list[i] + " , ";
            } else {
                result += list[i] + " ";
            }
        }
        result += "}";
        return result;
    }
}
