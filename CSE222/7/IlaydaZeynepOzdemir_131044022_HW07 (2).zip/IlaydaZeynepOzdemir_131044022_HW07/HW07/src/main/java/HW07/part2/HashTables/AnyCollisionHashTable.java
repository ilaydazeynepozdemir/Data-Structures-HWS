package HW07.part2.HashTables;

import HW07.DataStructures.MyArrayList;
import java.util.Hashtable;
import java.util.NoSuchElementException;

/**
 * Collision olmasini engeller Bunu chain metoduyla engelledik worst casede O(n)
 * best casede O(1)
 *
 * @author ilayda
 * @param <K>
 * @param <V>
 */
public class AnyCollisionHashTable<K, V> implements Interface_Hashtable<K, V> {

    Hashtable<Integer, MyArrayList<myEntry<K, V>>> allData;
    int size;

    /**
     * constructor
     */
    public AnyCollisionHashTable() {
        size = 0;
        allData = new Hashtable<Integer, MyArrayList<myEntry<K, V>>>();
    }

    /**
     * hashTable icine ekler
     *
     * @param key valuenun keyi
     * @param value eklenecek deger
     * @return eklenen deger
     */
    @Override
    public V put(K key, V value) {

        if (!allData.containsKey(key.hashCode())) {
            allData.put(key.hashCode(), new MyArrayList<myEntry<K, V>>());
        }

        allData.get(key.hashCode()).add(new myEntry<K, V>(key, value));
        ++size;
        return value;
    }

    /**
     * verilen keye karsilik gelen value degerini verir
     *
     * @param key bu keydeki deger istenir
     * @return value
     * @throws NoSuchElementException
     */
    @Override

    public V get(K key) {
        MyArrayList<myEntry<K, V>> values = allData.get(key.hashCode());
        if (values.size() == 1) {
            return values.get(0).getValue();
        } else {
            for (int i = 0; i < values.size(); ++i) {
                if (values.get(i).getKey().equals(key)) {
                    return values.get(i).getValue();
                }
            }
        }

        throw new NoSuchElementException();
    }

    /**
     * size'i dondurur
     *
     * @return integer
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * verilen keydeki degeri siler
     *
     * @param key bu keydeki deger sisilinmek istenir
     * @return silinen value doner
     * @throws NoSuchElementException
     */
    @Override
    public V remove(K key) {

        MyArrayList<myEntry<K, V>> retValues = allData.get(key.hashCode());
        if (retValues.size() == 1) {
            V returnV = retValues.get(0).getValue();
            allData.remove(key.hashCode());
            return returnV;
        } else {
            for (int i = 0; i < retValues.size(); ++i) {
                if (retValues.get(0).getKey().equals(key)) {
                    V returnV = retValues.get(0).getValue();
                    retValues.remove(0);
                    return returnV;
                }
            }
        }

        throw new NoSuchElementException();

    }

}
