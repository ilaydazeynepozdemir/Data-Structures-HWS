/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;

import HW07.part2.Person;

/**
 *price'i 4
 * @author ilayda
 */
public class Academician extends Person{
    
    public Academician(String name,String surname) {
        super(name, surname);
        setPrice(4);
    }
    
}
