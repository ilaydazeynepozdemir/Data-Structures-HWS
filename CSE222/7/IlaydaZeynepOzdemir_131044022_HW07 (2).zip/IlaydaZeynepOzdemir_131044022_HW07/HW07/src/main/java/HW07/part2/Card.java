/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;

/**
 *
 * @author ilayda
 */
abstract public class Card {

    protected int Barcode;
    private int uniqueCode;

    public Card() {
        Barcode = 0;
        uniqueCode = 0;
    }

    abstract public void setBarcode(int Barcode_);//bunun override edilmesi gerekir

    public int getBarcode() {
        return Barcode;
    }

    @Override
    public String toString() {
        return String.valueOf(getBarcode());
    }

    /*iki tane cardi unique sayi ve barcode sayesinde karsilastirir*/
 /*ikisi de ayni asistana aitse uniqueleri esit olur ve boylece esit olduklari kanitlanir*/
    /**
     * İki karti unique sayilari sayesinde birbirinden ayirir
     *
     * @param obj esitligine bakilacak card 
     * @return true false
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)//referans karsilastirmasi
        {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj.getClass().equals(this.getClass())) {
            Card other = (Card) obj;
            if (this.getUniqueCode() == other.getUniqueCode()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public void setUniqueCode(int uniqueCode_) {
        this.uniqueCode = uniqueCode_;
    }

    public int getUniqueCode() {
        return uniqueCode;
    }

}
