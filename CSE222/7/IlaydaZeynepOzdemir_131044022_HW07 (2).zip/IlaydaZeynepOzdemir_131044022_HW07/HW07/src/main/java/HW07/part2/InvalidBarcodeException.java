/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;

/**
 *istenilen aralik disinda barcode gelirse bu exception firlatiliyor
 * @author ilayda
 */
public class InvalidBarcodeException extends Exception{
    String error;

    public InvalidBarcodeException() {
        error = "Hatali kod.Sinirlara uyum saglamiyor";
    }

    @Override
    public String toString() {
        return error;
    }
    
    
}
