/**
 * AcademicCard
 */
package HW07.part2;

/**
 * 500 ile 15000 arasinda carddan extend olur
 *
 * @author ilayda
 */
public class AcademicCard extends Card {

    public AcademicCard(int givenBarcode) {
        super();
        setBarcode(givenBarcode);
    }
/**
 * 5000 ile 15000 arasinda olmasini kontrol eder
 * @param Barcode_ 
 */
    @Override
    public void setBarcode(int Barcode_) {
        try {
            if (5000 < Barcode_ && Barcode <= 15000) {
                this.Barcode = Barcode_ ;
            } else {
                throw new InvalidBarcodeException();
            }
        } catch (InvalidBarcodeException ex) {
            System.out.println(ex);
        }
    }

    /**
     * 5000 15000 arasindaki en buyuk asal sayiyla carpilarak bir hashcode
     * uretilir
     *
     * @return
     */
    @Override
    public int hashCode() {
        return getBarcode() * 14321;
    }

}
