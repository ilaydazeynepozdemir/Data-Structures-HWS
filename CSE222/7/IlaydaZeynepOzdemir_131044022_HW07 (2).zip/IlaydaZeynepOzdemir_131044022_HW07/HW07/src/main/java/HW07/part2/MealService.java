/*Meal service*/
package HW07.part2;

import HW07.part2.HashTables.UpdateHashTable;
import HW07.ReadFile_InArray;
import java.util.Hashtable;
import java.util.StringTokenizer;

/**
 * meal service academic ve student kartlarini birlestirir
 *
 * @author ilayda
 */
public class MealService {

    /**
     * tum kisiler bu hashtableda tutulur
     */
    UpdateHashTable<CombineCard, Person> AllPersons;

    /**
     * constructor
     *
     * @param filename verilerin alinacagi file adi
     */
    public MealService(String filename) {
        AllPersons = new UpdateHashTable<>();
        fillTable(filename);
    }

    /**
     * constructor veriler "input.txt"den alinir
     */
    public MealService() {
        AllPersons = new UpdateHashTable<>();
        fillTable("input.txt");
    }

    /**
     * hashtable doldururlur
     *
     * @param filename verilerin oldugu file adi
     */
    private void fillTable(String filename) {
        String tempName = null, tempSurname = null;
        String tempStuBarcode, tempAcaBarcode;
        CombineCard tempCard = null;
        Person added = null;
        int uniqueCount = 0;
        ReadFile_InArray read = new ReadFile_InArray(filename);
        for (int i = 0; i < read.getCountOfLine(); ++i) {
            String token = read.getLines(i);
            if (token != null) {

                StringTokenizer strToken = new StringTokenizer(token);
                if (strToken.hasMoreTokens()) {
                    tempName = strToken.nextToken();
//temp[0].setName();
                }
                if (strToken.hasMoreTokens()) {
                    tempSurname = strToken.nextToken();
//temp[0].setSurname(strToken.nextToken());
                }
                if (strToken.hasMoreTokens()) {
                    tempStuBarcode = strToken.nextToken();
                    if (tempStuBarcode.equals("-")) {
                        tempStuBarcode = null;
                    }
                    if (strToken.hasMoreTokens()) {
                        tempAcaBarcode = strToken.nextToken();
                        if (tempStuBarcode != null) {
                            added = new ResearchAsistant(tempName, tempSurname);
                        } else {
                            added = new Academician(tempName, tempSurname);
                        }
                        tempCard = new CombineCard(tempStuBarcode, tempAcaBarcode, ++uniqueCount);
                    }
                }
                AllPersons.put(tempCard, added);
                //System.out.println(tempCard + "  " + added);
            }
        }
    }

    /**
     * girilen barcode!un kime ait oldugu bulunur
     *
     * @param findedBarcode okunan barkod numarasi
     * @return person
     * @throws InvalidBarcodeException
     */
    public Person find(int findedBarcode) throws InvalidBarcodeException {
        if (findedBarcode >= 1000 && findedBarcode <= 5000) {
            StudentCard stu = new StudentCard(findedBarcode);
            CombineCard findStu = new CombineCard(stu, null);
            return AllPersons.get(findStu);
        } else if (findedBarcode > 5000 && findedBarcode <= 15000) {
            AcademicCard aca = new AcademicCard(findedBarcode);
            CombineCard findAca = new CombineCard(null, aca);
            return AllPersons.get(findAca);
        } else {
            throw new InvalidBarcodeException();
        }
    }

    /**
     * bu iki barcodelu kartlar ayni asistana mi ait sorusunun cevabını verir
     *
     * @param Barcode1
     * @param Barcode2
     * @return
     * @throws HW07.part2.ThisCardAbsentException kart yoksa exception yollar
     */
    public boolean isSameAsistantCards(int Barcode1, int Barcode2) throws ThisCardAbsentException {
        CombineCard card1 = AllPersons.getCombineCard(Barcode1);
        CombineCard card2 = AllPersons.getCombineCard(Barcode2);
        if (card1 == null || card2 == null) {
            throw new ThisCardAbsentException();
        } else {
            return card1.equals(card2);//ayni asistana aitse true doner
        }
    }

}
