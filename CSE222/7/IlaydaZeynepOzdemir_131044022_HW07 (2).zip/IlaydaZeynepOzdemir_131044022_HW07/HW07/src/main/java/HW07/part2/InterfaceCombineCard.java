/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;

/**
 *hashcode ve equalsi zorunlu hale getirdik
 * @author ilayda
 */
public interface InterfaceCombineCard {
    /**
     * her combine karta ozel bir sayi uretir
     * @return 
     */
    @Override
    public int hashCode();
/**
 * esitliklerine bakar
 * @param obj
 * @return 
 */
    @Override
    public boolean equals(Object obj) ;
}

