/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2.HashTables;

import java.util.Map;

/**
 *
 * @author ilayda
 */
public class myEntry<K, V> implements Map.Entry<K, V> {

    K key;
    V value;

    public myEntry(K key_, V value_) {
        key = key_;
        value = value_;
    }

    @Override
    public K getKey() {
        return key;
    }

    @Override
    public V getValue() {
        return value;
    }

    @Override
    public V setValue(V value_) {
        V old = value;//clone yazman gerekebilir bak!!
        value = value_;
        return old;
    }

}
