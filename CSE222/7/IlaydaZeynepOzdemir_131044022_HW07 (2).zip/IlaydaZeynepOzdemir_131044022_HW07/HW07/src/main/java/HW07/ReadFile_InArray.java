/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07;

import HW07.part1.Customer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 *
 * @author ilayda
 */
public class ReadFile_InArray {

    ArrayList<String> lines;
    int countOfLine;
    public ReadFile_InArray(String filename) {
        lines = new ArrayList<>();
        countOfLine = 0;
        readFile(filename);
    }

    private void readFile(String filename) {

        try {
            File file = new File(filename);
            BufferedReader reader = null;
            reader = new BufferedReader(new FileReader(file));
            String line = reader.readLine();//aciklama satiri

            while (line != null) {
                /*System.out.println(satir);*/
                line = reader.readLine();
                lines.add(line);
                //System.out.println(line);
                ++countOfLine;
            }
        } catch (FileNotFoundException ex) {
            System.out.println("dosya bulunamadi");
        } catch (IOException ex) {
            System.out.println("hata olustu");
        }
    }

    public String getLines(int index) {
        return lines.get(index);
    }

    public int getCountOfLine() {
        return countOfLine;
    }

    
    
    
    
    

}
