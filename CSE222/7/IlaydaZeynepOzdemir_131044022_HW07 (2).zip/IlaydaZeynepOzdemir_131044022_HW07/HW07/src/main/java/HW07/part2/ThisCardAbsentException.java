/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;

/**
 *
 * @author ilayda
 */
public class ThisCardAbsentException extends Exception{
    String error;

    public ThisCardAbsentException() {
        error = "HATA: boyle bir barkoda sahip kart yok! Barkodlari kontrol edin!";
    }

    @Override
    public String toString() {
        return error;
    }
    
    
    
}
