/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;


/**
 * 1000-5000
 * price'i 3
 *persondan extends olur
 * @author ilayda
 */
public class ResearchAsistant extends Academician {

    public ResearchAsistant(String name, String surname) {
        super(name, surname);
        setPrice(3);
    }

}
