/* part1 */
package HW07.part1;

import HW07.DataStructures.myPriorityQueue;
import HW07.ReadFile_InArray;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.sql.Time;
import java.util.Comparator;
import java.util.StringTokenizer;

/**
 * Comparator alir datalari okuyacagi dosya adini okur acik kalma time'ini alir
 * simulasyon sirasinda gerceklesenleri log dosyasina yazar (log dosyasi
 * appendtir! )
 *
 * @author ilayda
 */
public class SimulationSystem<E extends Customer> {

    private myPriorityQueue<E> SimulationPeople;/*simulasyon icin musterileri tutan priority queue*/
    private Comparator comparatorForSim;//customer
    private Time systemTime;
    private Time openTime;//sistemin acik kalma suresi
    private Time closedTime;
    final private String filename;
    final private String logFile;
    private FileWriter fileW;
    private PrintWriter write;
    boolean sign = false;
    int countGold = 0;
    int countSilver = 0;
    int countBronz = 0;

    /*Constructor*/
    /**
     * constructor
     *
     * @param typeForComparator queue icin comparator
     * @param filename_ veriler icin dosya
     * @param given_openTime acik kalma suresi
     * @param given_logFile simulasyon sirasinda olanlarin yazilacagi log
     * dosyasi
     */
    public SimulationSystem(Comparator typeForComparator, String filename_, Time given_openTime, String given_logFile) {
        openTime = given_openTime;
        closedTime = new Time(0);
        comparatorForSim = typeForComparator;
        SimulationPeople = new myPriorityQueue<>(comparatorForSim);
        filename = filename_;
        logFile = given_logFile;
        try {
            fileW = new FileWriter(logFile);
            write = new PrintWriter(fileW);
            write.println("\n\n~~ Simulasyon Basladi ~~\n\n");
        } catch (IOException ex) {
            System.err.println("dosya hatali");
        }

    }

    /**
     * customerin yazilmasi gereken bilgilerini loga yazar
     *
     * @param customer yazilacak customer
     */
    private void report(E customer) {
        if (customer.getCustomerType().equals("1")) {
            ++countGold;
        } else if (customer.getCustomerType().equals("2")) {
            ++countSilver;
        } else if (customer.getCustomerType().equals("3")) {
            ++countBronz;
        }

        write.println("islemi yapilan " + customer);
        write.println("guncel queue: " + SimulationPeople + "\n");
        write.println("bekleme suresi: " + customer.getWaitInQueue() + " dakika");
        write.println("\n~ sistem zamani: " + systemTime);
        write.println("-----------------------------------------------------------");
    }

    /**
     * islem sirasinda okumayi devam ettirir gelen customerin bekleme suresini
     * ayarlar kuyruga eklenmesi gerekenleri ekler sistem saatini ilerletir log
     * dosyasina bilgileri yazar
     *
     * @param cus islemni yapilacak customer
     * @param current o anki gecerli zaman
     * @param i dosyadan okunmasi gereken index
     * @return dosyada kalinan yerin indexi
     */
    private int process(E cus, Time current, int i) {
        E added = null;

        cus.setWaitInQueue(systemTime);
        if (systemTime.compareTo(new Time(closedTime.getHours() - 4, closedTime.getMinutes(), 0)) <= 0) {
            write.println("\n~ sistem zamani: " + systemTime);
        }
        //write.println("islemi yapilan " + cus);
        //  SimulationPeople.poll();
        current.setMinutes(current.getMinutes() + cus.getServiceTime());
        added = readThisLine(i);
        while (added != null && (added.getArrivalTime().compareTo(current) != 1)) {
            if (added != null && (added.getArrivalTime().compareTo(current) != 1)) {
                SimulationPeople.offer(added);
            }
            ++i;
            added = readThisLine(i);
        }

        systemTime.setMinutes(systemTime.getMinutes() + cus.getServiceTime());
        if (systemTime.compareTo(new Time(closedTime.getHours() - 4, closedTime.getMinutes(), 0)) <= 0) {
            //rapor kapanma suresinden 4 saat eksik zamana kadar yazilacak son dort saat yok
            report(cus);
        } else if (sign == false) {
            write.println(" Gold: " + countGold);
            write.println(" Silver: " + countSilver);
            write.println(" Bronz: " + countBronz);
            sign = true;
        }
        return i;
    }

    /**
     * kapanis saatini ayarlar
     */
    private void setClosedTime() {
        closedTime.setHours(systemTime.getHours() + openTime.getHours());
        closedTime.setMinutes(systemTime.getMinutes() + openTime.getMinutes());
        closedTime.setSeconds(systemTime.getSeconds() + openTime.getSeconds());
    }

    /**
     * simulasyonu yoneten method (eger kuyruk bossa kisinin islemini direk
     * yapar sonra kuyruk icine bakar ve oradakilerin islemini yapar)
     *
     * @param added simulasyon baslatilirken ilk okunan elemani alir
     */
    private void simulationOperations(E added) {

        int i = 1;
        while (systemTime.compareTo(closedTime) == -1) {

            //  System.out.println("sistem zamani: " + systemTime);
            if (added != null) {

                if (SimulationPeople.isEmpty()) {//bossa gelen elemanin islemini yapmaya yollar
                    //islem yapmaya yollanan eleman ayni zamanda okumaya devam eder
                    //ve kaldigi indexi dondurur
                    // SimulationPeople.offer(added);
                    i = process(added, (Time) systemTime.clone(), i);

                    //gelen elemanin islemini yaparkenki zaman diliminde olan
                    //diger elemanlari da queueya ekler
                }
                while (!SimulationPeople.isEmpty()) {
                    i = process(SimulationPeople.poll(), (Time) systemTime.clone(), i);
                }
                added = readThisLine(i);
                ++i;
            }
            systemTime.setMinutes(systemTime.getMinutes() + 1);
        }
    }

    /**
     * dosyanin ilk kisisini okur ve onun saatini sistem saati olarak ayarlar
     * (sistemin baslangic saati belirlenir)
     *
     * Sonra simulasyon operasyonlarini yoneten methodu cagirir
     *
     * @return simulasyon baslatilamazsa false doner
     */
    public boolean startSimulation() {
        E added = null;
        added = readThisLine(0);
        if (added != null) {
            systemTime = added.getArrivalTime();//ilk olan sistemin acilis saatiolur
            setClosedTime();
            simulationOperations(added);
            write.close();
            return true;
        } else {
            write.close();
            return false;
        }

    }

    /**
     * Verilen indexteki bilgiyi alir ve E tipinde bir objeye donusturur.her
     * dosyaya ozgu bir method oldugu icin gerekliyse override edilmeli
     *
     * @param i bu indexteki veriyi E tipine cevirip dondurur
     * @return E tipinde bir obje doldurup dondurur
     */
    public E readThisLine(int i) {
        ReadFile_InArray read = new ReadFile_InArray(filename);
        E temp = null;
        String tempStr;
        String tmp, tmp2;
        //for (int i = 0; i < read.getCountOfLine(); ++i) {
        String line = read.getLines(i);
        // System.out.println(line);
        if (line != null) {
            temp = (E) new Customer();
            StringTokenizer strTok = new StringTokenizer(line);
            if (strTok != null) {
                if (strTok.hasMoreTokens()) {
                    tempStr = strTok.nextToken();
                    // temp.setArrivalTime(tempStr);
                    StringTokenizer token2 = new StringTokenizer(tempStr, ":");
                    if (token2.hasMoreTokens()) {
                        tmp = token2.nextToken();
                        tmp2 = token2.nextToken(" ");
                        tmp2 = (String) tmp2.substring(1, tmp2.length());
                        Time tempTime = new Time(Integer.parseInt(tmp), Integer.parseInt(tmp2), 0);
                        // System.out.println(tempTime);

                        temp.setArrivalTime(tempTime);

                    }
                }//08:30
                if (strTok.hasMoreTokens()) {
                    temp.setServiceTime(Integer.parseInt(strTok.nextToken()));
                }//12
                if (strTok.hasMoreTokens()) {
                    tempStr = strTok.nextToken();
                }//customer
                if (strTok.hasMoreTokens()) {
                    temp.setCustomerType(strTok.nextToken());
                }//1
            }
        } else {
            temp = null;
        }
        // }
        return temp;

    }

}
