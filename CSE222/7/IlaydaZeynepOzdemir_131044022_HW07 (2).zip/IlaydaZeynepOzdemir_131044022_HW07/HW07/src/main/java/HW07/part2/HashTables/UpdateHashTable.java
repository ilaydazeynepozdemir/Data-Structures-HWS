/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2.HashTables;

import HW07.part2.HashTables.Interface_Hashtable;
import HW07.part2.HashTables.AnyCollisionHashTable;
import HW07.part2.CombineCard;
import HW07.part2.Person;
import java.util.Hashtable;

/**
 * CombineCard icindeki her barcodedan rahatlikla bulabiliriz
 *
 * @author ilayda
 */
public class UpdateHashTable<K extends CombineCard, V extends Person>
        implements Interface_Hashtable<K, V> {

    AnyCollisionHashTable<K, V> allData;
    AnyCollisionHashTable<Integer, K> keys;
//bundan her barcode'un bulundugu combine cardi rahatca elde ederiz

    /**
     * constructor
     */
    public UpdateHashTable() {
        this.allData = new AnyCollisionHashTable<>();
        this.keys = new AnyCollisionHashTable<>();
    }

    /**
     * hashTable icine ekler
     *
     * @param key valuenun keyi
     * @param value eklenecek deger
     * @return eklenen deger
     */
    @Override
    public V put(K key, V value) {
        if (key != null && value != null) {
            if (key.hasAcademicCard()) {
                keys.put(key.getBarcodeAca(), key);
            }
            if (key.hasStudentCard()) {
                keys.put(key.getBarcodeStu(), key);
            }
            allData.put(key, value);
            return value;
        } else {
            throw new NullPointerException("put metodu");
        }
    }

    public K getCombineCard(Integer Barcode) {
        return keys.get(Barcode);
    }

    /**
     * verilen keye karsilik gelen value degerini verir
     *
     * @param key bu keydeki deger istenir
     * @return value
     */
    @Override
    public V get(K key) {
        if (key != null) {
            if (key.hasStudentCard()) {
                K wanted = keys.get(key.getBarcodeStu());
                return allData.get(wanted);
            } else if (key.hasAcademicCard()) {
                K wanted = keys.get(key.getBarcodeAca());
                return allData.get(wanted);
            } else {
                return null;//ici bos olusturulmus bir key
            }

        } else {
            throw new NullPointerException();
        }
    }

    /**
     * size'i dondurur
     *
     * @return integer
     */
    @Override
    public int size() {
        return allData.size();
    }

    /**
     * verilen keydeki degeri siler
     *
     * @param key bu keydeki deger sisilinmek istenir
     * @return silinen value doner
     */
    @Override
    public V remove(K key) {
        if (key != null) {
            V returnV = allData.get(key);
            allData.remove(key);
            if (key.hasAcademicCard()) {
                keys.remove(key.getBarcodeAca());
            }
            if (key.hasStudentCard()) {
                keys.remove(key.getBarcodeStu());
            }
            return returnV;
        } else {
            throw new NullPointerException();
        }
    }
}
