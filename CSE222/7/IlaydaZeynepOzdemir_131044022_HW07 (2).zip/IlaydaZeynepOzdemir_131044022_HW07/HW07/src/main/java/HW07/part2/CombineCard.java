/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;

/**
 *
 * @author ilayda
 */
public class CombineCard implements InterfaceCombineCard {

    private Card student;
    private Card academic;

    /**
     * constructor
     *
     * @param givenStudent student barcode'unu alir
     * @param givenAcademic academic barcode'unu alir
     */
    public CombineCard(int givenStudent, int givenAcademic) {
        super();
        this.student = new StudentCard(givenStudent);
        this.academic = new AcademicCard(givenAcademic);
    }

    /**
     *
     * @param student kart olarak alir
     * @param academic kart olarak alir
     */
    public CombineCard(Card student, Card academic) {
        this.student = student;
        this.academic = academic;
    }

    /**
     *
     * @param givenStudent barkodu string olarak alir
     * @param givenAcademic barkodu string olarak alir
     * @param Unique unique sayilarini alir
     */
    public CombineCard(String givenStudent, String givenAcademic, int Unique) {
        if (givenStudent != null) {
            this.student = new StudentCard(Integer.parseInt(givenStudent));
            this.student.setUniqueCode(Unique);
        }
        if (givenAcademic != null) {
            this.academic = new AcademicCard(Integer.parseInt(givenAcademic));
            this.academic.setUniqueCode(Unique);
        }
    }

    /**
     * tek parametreli contructor
     *
     * @param givenBarcode verilen barkodun numarasina gore uygun tipte kart
     * olursuturur digerine null atar
     * @pre eger hashcode kullanilacaksa givenBarcode academic karta uygun
     * verilmeli
     */
    public CombineCard(int givenBarcode) {
        try {
            if (givenBarcode <= 5000 && givenBarcode >= 1000) {
                this.student = new StudentCard(givenBarcode);
            } else if (givenBarcode > 5000 && givenBarcode <= 15000) {
                this.academic = new AcademicCard(givenBarcode);
            } else {
                throw new InvalidBarcodeException();
            }
        } catch (InvalidBarcodeException ex) {
            System.out.println(ex);
        }
    }

    /**
     * student kartin varligini kontrol eder
     *
     * @return true false
     */
    public boolean hasStudentCard() {
        return (student != null);
    }

    /**
     * academic kartin varligini kontrol eder
     *
     * @return true false
     */
    public boolean hasAcademicCard() {
        return (academic != null);
    }

    @Override
    public int hashCode() {
        if (student != null && academic != null) {//researchAsistant
            return student.hashCode() ^ academic.hashCode();
        } else if (academic != null) {//academician
            return academic.hashCode();
        } else {
            throw new NullPointerException();
        }
    }

    /**
     * iki combine kartin hem academic olanlari hem de student olanlari esitse
     * true doner
     *
     * @param obj karsilastirilacak diger obje
     * @return true,false
     */
    @Override
    public boolean equals(Object obj) {
        boolean res = false;
        if (obj == null) {
            res = false;
        } else if (obj.getClass() == this.getClass()) {
            CombineCard other = (CombineCard) obj;

            if (other.academic != null) {
                if (other.academic.equals(this.academic)) {
                    res = true;
                }
            }

            if (other.student != null) {
                if (other.student.equals(this.student)) {
                    res = true;
                }
            }

            if (other.student == null && other.academic == null) {
                res = false;
            }
        } else {
            res = false;
        }
        return res;
    }

    /**
     * academic carti set eder
     *
     * @param academic_
     */
    public void setAcademic(AcademicCard academic_) {
        this.academic = academic_;
    }

    /**
     * student karti set eder
     *
     * @param student_
     */
    public void setStudent(StudentCard student_) {
        this.student = student_;
    }

    /**
     * combine karti string haline getirir
     *
     * @return
     */
    @Override
    public String toString() {
        return "studentCard:" + student + " academicCard:" + academic;
    }

    /**
     * student kartinin barkodunu verir
     *
     * @return
     */
    public int getBarcodeStu() {

        return student.getBarcode();

    }

    /**
     * academic kartinin barkodunu verir
     *
     * @return
     */
    public int getBarcodeAca() {
        return academic.getBarcode();
    }

}
