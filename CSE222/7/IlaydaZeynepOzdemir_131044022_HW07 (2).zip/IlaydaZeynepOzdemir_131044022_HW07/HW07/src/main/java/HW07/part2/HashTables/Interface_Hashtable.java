/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2.HashTables;

/**
 *
 * @author ilayda
 * @param <K>
 * @param <V>
 */
public interface Interface_Hashtable<K, V> {

    /**
     * hash table icine ekler
     *
     * @param key key olarak kullanilacak eleman
     * @param value deger olarak kullaniclacak eleman
     * @return koydugu degeri return eder
     */
    public V put(K key, V value);

    /**
     * verilen keye karsilik gelen elemani retur neder
     *
     * @param key istenilen elmenain keyi
     * @return istenilen deger
     */
    V get(K key);

    /**
     * icindeki eleman sayisi
     *
     * @return integer size
     */

    int size();

    /**
     * table'i string hale getirir
     *
     * @return
     */
    String toString();

    /**
     * verilen elemana karsilik gelen degeri siler
     *
     * @param key
     * @return
     */
    V remove(K key);
}
