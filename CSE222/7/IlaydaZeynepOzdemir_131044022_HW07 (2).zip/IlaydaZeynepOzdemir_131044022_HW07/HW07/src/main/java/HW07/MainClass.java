/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07;

import HW07.part2.MealService;
import HW07.part1.Customer;
import HW07.part1.SimulationSystem;
import HW07.part2.InvalidBarcodeException;
import HW07.part2.ThisCardAbsentException;
import java.sql.Time;

/**
 *
 * @author ilayda
 */
public class MainClass {

    public static void main(String[] args) {
        /*simulasyon sonuclari logFile!a yazar*/
        TestSimulationSystem1();
        TestSimulationSystem2();
        /*mealService ekrana basar*/
        TestMealService(5001, 10000);
        TestMealService(1023, 1000);
        TestMealService(1077, 13396);
        TestMealService(1121, 13792);
        TestMealService(5001, 1000);

    }

    public static void TestSimulationSystem1() {//data1.txt
        Time timerOfOpen = new Time(12, 30, 0);
        Customer forCompare = new Customer();
        SimulationSystem simulation1
                = new SimulationSystem(forCompare,
                        "data1.txt", timerOfOpen, "logFile1.txt");
        simulation1.startSimulation();

    }

    public static void TestSimulationSystem2() {//data2.txt
        Customer forCompare = new Customer();
        Time timerOfOpen = new Time(23, 59, 0);
        SimulationSystem simulation2 = new SimulationSystem(forCompare,
                "data2.txt", timerOfOpen, "logFile2.txt");
        simulation2.startSimulation();

    }

    public static void TestMealService(int Barcode1, int Barcode2) {//input.txt
        MealService service1 = new MealService("input.txt");
        System.out.println("alinan iki barkod ayni asistanin kartlarina mi ait?");
        try {
            if (service1.isSameAsistantCards(Barcode1, Barcode2)) {
                System.out.println("Kartlar ayni asistana ait");
                System.out.println("Asistan adi: " + service1.find(Barcode2));
            } else {
                System.out.println("iki barkod ayni asistana ait degil");
            }
        } catch (ThisCardAbsentException ex) {
            System.out.println(ex);
        } catch (InvalidBarcodeException ex) {
            System.out.println(ex);
        }
        
        System.out.println("-------------------------------------------------------");
        
        
    }

}
