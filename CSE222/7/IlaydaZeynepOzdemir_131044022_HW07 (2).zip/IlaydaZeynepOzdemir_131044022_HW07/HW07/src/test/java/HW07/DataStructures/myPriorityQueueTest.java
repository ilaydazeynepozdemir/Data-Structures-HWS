/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.DataStructures;

import HW07.part1.Customer;
import java.util.Comparator;
import java.util.Iterator;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class myPriorityQueueTest {

    public myPriorityQueueTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of offer method, of class myPriorityQueue.
     */
    @Test
    public void testOffer() {
        System.out.println("offer");
        myPriorityQueue instance = new myPriorityQueue();

        boolean result = instance.offer(5);
        boolean expResult;
        if (!instance.isEmpty()) {
            expResult = true;
        } else {
            expResult = false;
        }
        assertEquals(expResult, result);
    }

    /**
     * Test of peek method, of class myPriorityQueue.
     */
    @Test
    public void testPeek() {
        System.out.println("peek");
        myPriorityQueue instance = new myPriorityQueue();
        instance.offer(5);
        Object expResult = 5;
        Object result = instance.peek();
        assertEquals(expResult, result);
    }

    /**
     * Test of poll method, of class myPriorityQueue.
     */
    @Test
    public void testPoll() {
        System.out.println("poll");
        myPriorityQueue instance = new myPriorityQueue();
        instance.offer(3);
        Object expResult = 3;
        Object result = instance.poll();
        assertEquals(expResult, result);
    }

    /**
     * Test of size method, of class myPriorityQueue.
     */
    @Test
    public void testSize() {
        System.out.println("size");
        myPriorityQueue instance = new myPriorityQueue();
        instance.offer(6);
        int expResult = 1;
        int result = instance.size();
        assertEquals(expResult, result);
    }

}
