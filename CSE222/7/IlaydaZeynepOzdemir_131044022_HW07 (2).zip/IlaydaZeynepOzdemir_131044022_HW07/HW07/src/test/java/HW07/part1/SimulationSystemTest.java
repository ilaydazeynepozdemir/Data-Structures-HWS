/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part1;

import java.sql.Time;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class SimulationSystemTest {
    
    public SimulationSystemTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of startSimulation method, of class SimulationSystem.
     */
    @Test
    public void testStartSimulation() {
        System.out.println("startSimulation");
        SimulationSystem instance = new SimulationSystem(new Customer(), "data1.txt", new Time(15, 0, 0), "test.txt");
        boolean expResult = true;
        boolean result = instance.startSimulation();
        assertEquals(expResult, result);
    }

    /**
     * Test of readThisLine method, of class SimulationSystem.
     */
    @Test
    public void testReadThisLine() {
        System.out.println("readThisLine");
        int i = 0;
        SimulationSystem instance = new SimulationSystem(new Customer(), "data1.txt", new Time(15, 0, 0), "test.txt");
        Customer expResult = new Customer();
        expResult.setArrivalTime(new Time(8,30,0));
        expResult.setServiceTime(12);
        expResult.setCustomerType("1");
        Customer result = instance.readThisLine(i);
        assertEquals(expResult, result);
    }
    
}
