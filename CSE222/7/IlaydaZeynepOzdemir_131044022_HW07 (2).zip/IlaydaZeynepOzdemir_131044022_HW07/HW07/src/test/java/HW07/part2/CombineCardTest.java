/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class CombineCardTest {
    
    public CombineCardTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of hasStudentCard method, of class CombineCard.
     */
    @Test
    public void testHasStudentCard() {
        System.out.println("hasStudentCard");
        CombineCard instance = new CombineCard(1000);
        boolean expResult = true;
        boolean result = instance.hasStudentCard();
        assertEquals(expResult, result);
    }

    /**
     * Test of hasAcademicCard method, of class CombineCard.
     */
    @Test
    public void testHasAcademicCard() {
        System.out.println("hasAcademicCard");
        CombineCard instance = new CombineCard(4999);
        boolean expResult = false;
        boolean result = instance.hasAcademicCard();
        assertEquals(expResult, result);
    }

    /**
     * Test of hashCode method, of class CombineCard.
     */
    @Test
    public void testHashCode() {
        System.out.println("hashCode");
        CombineCard instance = new CombineCard("2000","14000",2);
        int expResult = (new StudentCard(2000)).hashCode() ^ (new AcademicCard(14000).hashCode());
        int result = instance.hashCode();
        assertEquals(expResult, result);
    }

    /**
     * Test of equals method, of class CombineCard.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        Object obj = new CombineCard(1000);
        CombineCard instance =  new CombineCard(1000);
        boolean expResult = true;
        boolean result = instance.equals(obj);
        assertEquals(expResult, result);
    }

    /**
     * Test of setAcademic method, of class CombineCard.
     */
    @Test
    public void testSetAcademic() {
        System.out.println("setAcademic");
        AcademicCard academic_ = new AcademicCard(5007);
        CombineCard instance = new CombineCard(1000);
        instance.setAcademic(academic_);
    }

    /**
     * Test of setStudent method, of class CombineCard.
     */
    @Test
    public void testSetStudent() {
        System.out.println("setStudent");
        StudentCard student_ = new StudentCard(1000);
        CombineCard instance = new CombineCard(5006);
        instance.setStudent(student_);
    }

    /**
     * Test of toString method, of class CombineCard.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        CombineCard instance = new CombineCard(1000);
        String expResult = "studentCard:" + 1000 + " academicCard:" + null;
        String result = instance.toString();
        assertEquals(expResult, result);
    }

    
}
