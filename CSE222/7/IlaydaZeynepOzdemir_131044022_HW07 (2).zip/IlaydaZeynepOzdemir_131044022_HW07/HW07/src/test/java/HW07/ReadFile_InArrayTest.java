/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class ReadFile_InArrayTest {
    
    public ReadFile_InArrayTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getLines method, of class ReadFile_InArray.
     */
    @Test
    public void testGetLines() {
        System.out.println("getLines");
        int index = 0;
        ReadFile_InArray instance = new ReadFile_InArray("data1.txt");
        String expResult = "08:30           12              Customer 1";
        String result = instance.getLines(index);
        assertEquals(expResult, result);
    }

  
    
}
