/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2.HashTables;

import HW07.part2.HashTables.UpdateHashTable;
import HW07.part2.AcademicCard;
import HW07.part2.Academician;
import HW07.part2.CombineCard;
import HW07.part2.Person;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class UpdateHashTableTest {

    public UpdateHashTableTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of put method, of class UpdateHashTable.
     */
    @Test
    public void testPut() {
        System.out.println("put");
        CombineCard key = new CombineCard(13000);
        Person value = new Academician("1", "1");
        UpdateHashTable instance = new UpdateHashTable();
        Person expResult = new Academician("1", "1");
        Person result = instance.put(key, value);
        assertEquals(expResult, result);
    }

    /**
     * Test of getCombineCard method, of class UpdateHashTable.
     */
    @Test
    public void testGetCombineCard() {
        System.out.println("getCombineCard");
        Integer Barcode = 12055;
        CombineCard key = new CombineCard(12055);
        Person value = new Academician("2", "2");
        UpdateHashTable instance = new UpdateHashTable();
        instance.put(key, value);
        CombineCard expResult = key;
        CombineCard result = instance.getCombineCard(Barcode);
        assertEquals(expResult, result);
    }

    /**
     * Test of get method, of class UpdateHashTable.
     */
    @Test
    public void testGet() {
        System.out.println("get");
        CombineCard key = new CombineCard(13000);
        Person value = new Academician("2", "2");
        UpdateHashTable instance = new UpdateHashTable();
        if(instance == null)
            System.err.println(" NULLL");
        instance.put(key, value);
        Person expResult = value;
        Person result = instance.get(key);
        assertEquals(expResult, result);
    }

    /**
     * Test of size method, of class UpdateHashTable.
     */
    @Test
    public void testSize() {
        System.out.println("size");
        CombineCard key = new CombineCard(13000);
        Person value = new Academician("2", "2");
        UpdateHashTable instance = new UpdateHashTable();
        instance.put(key, value);
        int expResult = 1;
        int result = instance.size();
        assertEquals(expResult, result);
    }

    /**
     * Test of remove method, of class UpdateHashTable.
     */
    @Test
    public void testRemove() {
        System.out.println("remove");
        CombineCard key = new CombineCard(13000);
        Person value = new Academician("2", "2");
        UpdateHashTable instance = new UpdateHashTable();
        instance.put(key, value);
        Person expResult = value;
        Person result = instance.remove(key);
        assertEquals(expResult, result);
    }

}
