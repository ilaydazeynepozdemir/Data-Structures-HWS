/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class StudentCardTest {
    
    public StudentCardTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setBarcode method, of class StudentCard.
     */
    @Test
    public void testSetBarcode() {
        System.out.println("setBarcode");
        int Barcode_ = 0;
        StudentCard instance = new StudentCard(200);
        instance.setBarcode(Barcode_);
    }

    /**
     * Test of hashCode method, of class StudentCard.
     */
    @Test
    public void testHashCode() {
        System.out.println("hashCode");
        StudentCard instance = new StudentCard(1000);
        int expResult = 1000*4999;
        int result = instance.hashCode();
        assertEquals(expResult, result);
    }
    
}
