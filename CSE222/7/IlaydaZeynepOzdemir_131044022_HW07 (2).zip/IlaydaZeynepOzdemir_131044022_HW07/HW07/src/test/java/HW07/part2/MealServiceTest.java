/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class MealServiceTest {
    
    public MealServiceTest() {
       
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("HW07.part2.MealServiceTest.setUpClass()");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("HW07.part2.MealServiceTest.tearDownClass()");
    }
    
    @Before
    public void setUp() {
         
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of find method, of class MealService.
     */
    @Test
    public void testFind() throws Exception {
        System.out.println("find");
        int findedBarcode = 10000;
        MealService instance = new MealService();
        Person expResult = new ResearchAsistant("Ali","Veli");
        Person result = instance.find(findedBarcode);
        assertEquals(expResult, result);
    }

    /**
     * Test of isSameAsistantCards method, of class MealService.
     */
    @Test
    public void testIsSameAsistantCards() throws ThisCardAbsentException {
        System.out.println("isSameAsistantCards");
        int Barcode1 = 0;
        int Barcode2 = 0;
        MealService instance = new MealService();
        boolean expResult = true;
        boolean result = instance.isSameAsistantCards(10000, 5001);
        assertEquals(expResult, result);
    }
    
}
