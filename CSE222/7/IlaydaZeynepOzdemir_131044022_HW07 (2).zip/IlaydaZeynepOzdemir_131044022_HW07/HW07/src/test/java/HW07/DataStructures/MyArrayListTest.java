/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.DataStructures;

import HW07.part1.Customer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class MyArrayListTest {

    public MyArrayListTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of size method, of class MyArrayList.
     */
    @Test
    public void testSize() {
        System.out.println("size");
        MyArrayList instance = new MyArrayList();
        int expResult = 0;
        int result = instance.size();
        assertEquals(expResult, result);
    }

    /**
     * Test of get method, of class MyArrayList.
     */
    @Test
    public void testGet() {
        System.out.println("get");
        int index = 0;
        MyArrayList instance = new MyArrayList();
        instance.add(5);
        Object expResult = 5;
        Object result = instance.get(index);
        assertEquals(expResult, result);
    }

    /**
     * Test of set method, of class MyArrayList.
     */
    @Test
    public void testSet() {
        System.out.println("set");
        int index = 0;
        Object newValue = new Customer();
        MyArrayList instance = new MyArrayList();
        Object expResult = null;
        Object result = instance.set(index, newValue);
        assertEquals(expResult, result);
    }

    /**
     * Test of indexOf method, of class MyArrayList.
     */
    @Test
    public void testIndexOf() {
        System.out.println("indexOf");
        Object target = 5;
        MyArrayList instance = new MyArrayList();
        instance.add(5);
        int expResult = 0;
        int result = instance.indexOf(target);
        assertEquals(expResult, result);
    }

    /**
     * Test of resize method, of class MyArrayList.
     */
    @Test
    public void testResize() {
        System.out.println("resize");
        MyArrayList instance = new MyArrayList();
        instance.resize();
    }

    /**
     * Test of clear method, of class MyArrayList.
     */
    @Test
    public void testClear() {
        System.out.println("clear");
        MyArrayList instance = new MyArrayList();
        instance.clear();
    }

    /**
     * Test of remove method, of class MyArrayList.
     */
    @Test
    public void testRemove() {
        System.out.println("remove");
        int index = 0;
        MyArrayList instance = new MyArrayList();
        instance.add(5);
        Object expResult = 5;
        Object result = instance.remove(index);
        assertEquals(expResult, result);
    }

    /**
     * Test of add method, of class MyArrayList.
     */
    @Test
    public void testAdd() {
        System.out.println("add");
        Object item = null;
        MyArrayList instance = new MyArrayList();
        boolean expResult = true;
        boolean result = instance.add(item);
        assertEquals(expResult, result);
    }


}
