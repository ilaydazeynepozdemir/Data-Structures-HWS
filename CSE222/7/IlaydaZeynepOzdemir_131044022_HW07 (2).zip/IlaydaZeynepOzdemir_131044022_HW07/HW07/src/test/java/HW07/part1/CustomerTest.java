/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW07.part1;

import java.sql.Time;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class CustomerTest {

    public CustomerTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of setWaitInQueue method, of class Customer.
     * set ile get vbir arada kontrol edildi
     */
    @Test
    public void testSetWaitInQueue() {
        System.out.println("setWaitInQueue");
        Time timeOfNow = new Time(0,0,0);
        Customer instance = new Customer();
        instance.setWaitInQueue(timeOfNow);
        assertEquals(0, instance.getWaitInQueue());
    }

    /**
     * Test of compare method, of class Customer.
     */
    @Test
    public void testCompare() {
        System.out.println("compare");
        Object obj1 = new Customer("1");
        Object obj2 = new Customer("1");
        Customer instance = new Customer();
        int expResult = 0;
        int result = instance.compare(obj1, obj2);
        assertEquals(expResult, result);
    }


}
