/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW05;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author ilayda
 */
public class MainTest {
    
    public MainTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class Main.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Main.main(args);
    }
    
    /**
     * Test of testPart1 method, of class Main.
     */
    @Test
    public void testTestPart1() {
        System.out.println("testPart1");
        Main.testPart1();
    }

    /**
     * Test of testPart2 method, of class Main.
     */
    @Test
    public void testTestPart2() {
        System.out.println("testPart2");
        Main.testPart2();
    }

    /**
     * Test of testPart3 method, of class Main.
     */
    @Test
    public void testTestPart3() {
        System.out.println("testPart3");
        Main.testPart3();
    }
    
}
