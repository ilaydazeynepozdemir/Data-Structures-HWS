/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW05;

import junit.framework.TestCase;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class LinkedListRecTest extends TestCase {
    
    public LinkedListRecTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        
        
    }
    
    @AfterClass
    public static void tearDownClass() {
        
    }
    
    @Before
    @Override
    public void setUp() {
        System.out.println("### LinkedListRec Testi Baslangici ###");
    }
    
    @After
    @Override
    public void tearDown() {
        System.out.println("### LinkedListRec Testi Bitisi ###");
    }

    /**
     * Test of size method, of class LinkedListRec.
     */
    @Test
    public void testSize() {
        System.out.println("size");
        LinkedListRec instance = new LinkedListRec();
        instance.add("ali");
        instance.add("veli");
        int expResult = 2;
        int result = instance.size();
        assertEquals(expResult, result);
    }

    /**
     * Test of toString method, of class LinkedListRec.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        LinkedListRec instance = new LinkedListRec();
        instance.add(1);
        String expResult = "1 ";
        String result = instance.toString();
        assertEquals(expResult, result);
    }

    /**
     * Test of add method, of class LinkedListRec.
     */
    @Test
    public void testAdd() {
        System.out.println("add");
        Object data = null;
        LinkedListRec instance = new LinkedListRec();
        instance.add(data);
    }

    /**
     * Test of removeOneElement method, of class LinkedListRec.
     */
    @Test
    public void testRemoveOneElement() {
        System.out.println("removeOneElement");
        Object outData = 1;
        LinkedListRec instance = new LinkedListRec();
        instance.add(2);
        instance.add(2);
        instance.add(2);
        boolean expResult = false;
        boolean result = instance.removeOneElement(outData);
        assertEquals(expResult, result);
    }

    /**
     * Test of remove method, of class LinkedListRec.
     */
    @Test
    public void testRemove() {
        System.out.println("remove");
        Object outData = 1;
        LinkedListRec instance = new LinkedListRec();
        instance.add(1);
        instance.add(2);
        instance.add(1);
        instance.add(2);
        instance.add(1);
        instance.add(2);
        boolean expResult = true;
        boolean result = instance.remove(outData);
        assertEquals(expResult, result);
    }
    
}
