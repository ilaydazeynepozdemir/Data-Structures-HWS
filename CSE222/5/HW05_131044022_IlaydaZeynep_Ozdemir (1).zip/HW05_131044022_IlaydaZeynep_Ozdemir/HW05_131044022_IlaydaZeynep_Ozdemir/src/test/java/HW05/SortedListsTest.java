/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW05;

import java.util.ArrayList;
import java.util.List;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class SortedListsTest extends TestCase {

    ArrayList list1__ = new ArrayList();
    ArrayList list2__ = new ArrayList();

    public SortedListsTest() {
        for (int i = 0;
                i < 5; ++i) {
            list1__.add(i+1);
        }
        for (int i = 0;
                i < 3; ++i) {
            list2__.add(i+1);
        }

    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    @Override
    public void setUp() {
        System.out.println("##### SortedLists Test Baslangici #####");

    }

    @After
    @Override
    public void tearDown() {
        System.out.println("##### SortedLists Test Bitisi #####");
    }

    /**
     * Test of intersectionOfLists method, of class SortedLists.
     *
     */
    @Test
    public void testIntersectionOfLists() {
        System.out.println("intersectionOfLists");
        SortedLists instance = new SortedLists(list1__, list2__);
       
        //SortedLists instance = new SortedLists(null, null);
        List expResult = new ArrayList();
        //System.out.println(list1__);
        expResult.add(1);
        expResult.add(2);
        expResult.add(3);
        List result = instance.intersectionOfLists();
        assertEquals(expResult, result);
    }

    /**
     * Test of unionOfLists method, of class SortedLists.
     *
     */
    @Test
    public void testUnionOfLists() {
        System.out.println("unionOfLists");
        SortedLists instance = new SortedLists(list1__, list2__);
        List expResult = new ArrayList();
        //System.out.println(list1__);
        expResult.add(1);
        expResult.add(2);
        expResult.add(3);
        expResult.add(4);
        expResult.add(5);
        List result = instance.unionOfLists();
        assertEquals(expResult, result);
    }

    /**
     * Test of isSubset method, of class SortedLists.
     *
     */
    @Test
    public void testIsSubset() {
        System.out.println("isSubset");
        SortedLists instance = new SortedLists(list1__, list2__);
        boolean expResult = true;
        boolean result = instance.isSubset();
        assertEquals(expResult, result);
    }

}
