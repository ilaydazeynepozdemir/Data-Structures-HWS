/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW05;

import java.util.Stack;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ilayda
 */
public class HanoiTest {
    
    public HanoiTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        System.out.println("###Hanoi testi baslangici###");
    }
    
    @After
    public void tearDown() {
         System.out.println("###Hanoi testi bitisi###");
    }

    /**
     * Test of TowerOfHanoi method, of class Hanoi.
     */
    @Test
    public void testTowerOfHanoi() {
        System.out.println("TowerOfHanoi");
        int disksize = 4;
        Stack src = new Stack();
        Stack dst = new Stack();
        Stack aux = new Stack();
        Hanoi instance = new Hanoi();
        instance.TowerOfHanoi(disksize, src, dst, aux);
    }
    
}
