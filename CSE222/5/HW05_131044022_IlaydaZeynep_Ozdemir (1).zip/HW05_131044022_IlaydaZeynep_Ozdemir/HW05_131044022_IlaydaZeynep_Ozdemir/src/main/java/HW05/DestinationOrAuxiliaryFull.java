
package HW05;

/**
 *Hanoiye gonderilen destination veya auxiliary stacklerinde eleman varsa firlatilir
 * @author ilayda
 */
public class DestinationOrAuxiliaryFull extends Exception {

    String error;

    public DestinationOrAuxiliaryFull() {
        error = "Gonderilen Destination veya Auxiliary dolu!";
    }

    @Override
    public String toString() {
        return error;
    }
    
    

}
