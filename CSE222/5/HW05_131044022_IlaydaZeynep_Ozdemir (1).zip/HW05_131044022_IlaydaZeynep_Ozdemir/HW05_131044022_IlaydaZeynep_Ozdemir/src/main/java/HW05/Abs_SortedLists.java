/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW05;

import java.util.List;

/**
 *
 * @author ilayda
 * @param <E>
 */
abstract public class Abs_SortedLists<E extends Comparable<E>> implements InterfaceSortedLists<E>{

    @Override
    abstract public List<E> intersectionOfLists();

    @Override
    abstract public List<E> unionOfLists();

    @Override
    abstract public boolean isSubset();
    
}
