/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW05;

/**
 *
 * @author ilayda
 */
public interface InterfaceLinkedListRec<E> {

    public int size();

    public void add(E data);

    public boolean remove(E outData);

}
