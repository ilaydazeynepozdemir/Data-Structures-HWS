/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW05;

/**
 *
 * @author ilayda
 * @param <E>
 */
abstract public class Abs_LinkedListRec<E> implements InterfaceLinkedListRec<E> {

    @Override
    abstract public int size();

    @Override
    abstract public void add(E data);

    @Override
    abstract public boolean remove(E outData);
}
