/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW05;

import java.util.ArrayList;
import java.util.Stack;

/**
 *
 * @author ilayda
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("#########Part1 Testi#########");
        testPart1();
        System.out.println("#########Part2 Testi#########");
        testPart2();
        System.out.println("#########Part3 Testi#########");
        testPart3();
    }

    public static void testPart1() {
        Hanoi part1 = new Hanoi();
        Stack st1 = new Stack();
        Stack st2 = new Stack();
        Stack st3 = new Stack();
        System.out.println("~~~~~~~~~3 Disk");
        part1.TowerOfHanoi(3, st1, st2, st3);
        Stack st1_ = new Stack();
        Stack st2_ = new Stack();
        Stack st3_ = new Stack();
        System.out.println("~~~~~~~~~5 Disk");
        part1.TowerOfHanoi(5, st1_, st2_, st3_);
    }

    public static void testPart2() {
        LinkedListRec part2 = new LinkedListRec();
        part2.add(2);
        part2.add(3);
        part2.add(2);
        part2.add(2);
        part2.add(2);
        part2.add(7);
        System.out.println("list = " + part2);
        System.out.println("Tum 2'ler silinecek");
        //part2.remove(2);
        System.out.println(part2.remove(2));
        System.out.println("list = " + part2);
    }

    public static void testPart3() {
        ArrayList list1_ = new ArrayList();
        ArrayList list2_ = new ArrayList();
        list1_.add(1);
        list1_.add(2);
        list1_.add(12);
        list1_.add(3);
        list1_.add(7);

        list2_.add(1);
        list2_.add(3);
        list2_.add(3);
        list2_.add(70);

        SortedLists part3 = new SortedLists(list1_, list2_);

        System.out.println("list1 = " + list1_ + "\n" + "list2 = " + list2_ + "\n");
        //aldigim degismiyor
        System.out.println("iki kumenin kesisimi");
        System.out.println(part3.intersectionOfLists());
        System.out.println("iki kumenin birlesimi");
        System.out.println(part3.unionOfLists());
        if (part3.isSubset()) {
            System.out.println("list2 list1'in alt kumesi");
        } else {
            System.out.println("list2 list1'in alt kumesi degil");
        }

    }
}
