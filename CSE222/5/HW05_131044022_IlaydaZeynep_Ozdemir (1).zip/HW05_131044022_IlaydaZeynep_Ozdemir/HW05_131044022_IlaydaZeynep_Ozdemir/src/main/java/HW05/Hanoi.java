package HW05;

/*
 * Java Program to Solve Tower of Hanoi Problem using Stacks
 */
import static java.lang.Math.pow;
import java.util.*;

/* Class TowerOfHanoiUsingStacks */
public class Hanoi implements InterfaceHanoi {

    Stack<Integer>[] towers;

    /**
     * constructor
     */
    public Hanoi() {
        towers = new Stack[3];
        towers[0] = null;//src
        towers[1] = null;//dst
        towers[2] = null;//aux
    }
    /*####Private####*/

    /**
     * ekrana rapor olarak basar
     *
     * @param fromTower buradan
     * @param toTower buraya tasindi
     * @param disk tasinan disk
     */
    private void moveDiskReport(String fromTower, String toTower, int disk) {

        System.out.printf("Disk %d : %s -> %s tasindi\n",
                disk, fromTower, toTower);
    }

    /**
     * sourcedan destinationa tasimayi yapar
     *
     * @param src source olarak kullanilacak stack indexi
     * @param dest destionation oalrak kullanilacak stack indexi
     * @param source source olarak kullanilacak yer adi
     * @param destination destinayion olarak kullanilacak yer adi
     */
    private void move(int src, int dest, String source, String destination) {

        int topSource = 0;
        int topDest = 0;

        if (towers[src] != null && !(towers[src].isEmpty())) {
            topSource = (int) towers[src].pop();
        }

        if (towers[1] != null && !(towers[dest].isEmpty())) {
            topDest = (int) towers[dest].pop();
        }
        if (topSource == 0) {
            towers[src].push(topDest);
            moveDiskReport(destination, source, topDest);
        } else if (topDest == 0) {
            towers[dest].push(topSource);
            moveDiskReport(source, destination, topSource);

        } else if (topSource > topDest) {
            towers[src].push(topSource);
            towers[src].push(topDest);
            moveDiskReport(destination, source, topDest);
        } else {
            towers[dest].push(topDest);
            towers[dest].push(topSource);
            moveDiskReport(source, destination, topSource);
        }
    }

    /**
     * source olarak kullandigimiz stack doldurulur 0.indexteki
     *
     * @param disksize disksize diskleri belirledigi icin alinir
     */
    private void fillDisks(int disksize) {
        for (int i = disksize; i > 0; --i) {
            towers[0].push(i);
        }
    }

    /*####Public####*/
    /**
     * 3 tane bos stack alir. source bos degilse doldurma islemi yapmaz
     * sourcedaki diskleri destinationa tasir
     *
     * @param disksize disk sayisi
     * @param src kaynak
     * @param dst tasinacak yer
     * @param aux bu stack tasimada kullanilir
     */
    public void TowerOfHanoi(int disksize, Stack src, Stack dst, Stack aux) {
        String source = "source";
        String destination = "destination";
        String auxiliary = "auxiliary";
        if (disksize % 2 == 0) {
            String temp = destination;
            destination = auxiliary;
            auxiliary = temp;
        }
        try {
            if ((!dst.empty()) || (!aux.empty())) {
                throw new DestinationOrAuxiliaryFull();
            }

            towers[0] = src;
            towers[1] = dst;
            towers[2] = aux;

            int steps = (int) (pow(2, disksize) - 1);
            if (src.empty()) {
                fillDisks(disksize);
            }

            System.out.println("src =" + towers[0]);
            System.out.println("dst =" + towers[1]);
            System.out.println("aux =" + towers[2]);

            for (int i = 1; i <= steps; ++i) {
                if (i % 3 == 1) {
                    move(0, 1, source, destination);//src,dst
                } else if (i % 3 == 2) {
                    move(0, 2, source, auxiliary);//src,aux
                } else if (i % 3 == 0) {
                    move(2, 1, auxiliary, destination);//aux,dst
                }
            }

            System.out.println("###Tasinmis hali###");
            if (disksize % 2 == 0) {
                System.out.println("src =" + towers[0]);
                System.out.println("dst =" + towers[2]);
                System.out.println("aux =" + towers[1]);
            } else {
                System.out.println("src =" + towers[0]);
                System.out.println("dst =" + towers[1]);
                System.out.println("aux =" + towers[2]);
            }
        } catch (DestinationOrAuxiliaryFull ex) {
            System.out.println(ex);
        }
    }

}
