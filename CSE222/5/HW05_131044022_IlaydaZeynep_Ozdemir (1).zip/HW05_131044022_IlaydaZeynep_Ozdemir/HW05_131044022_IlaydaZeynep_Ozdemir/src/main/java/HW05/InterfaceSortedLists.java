/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW05;

import java.util.List;

/**
 *
 * @author ilayda
 * @param <E>
 */
public interface InterfaceSortedLists <E> {

    public List<E> intersectionOfLists(); //returns intersection set as a list of list1 and list 2
    public List<E> unionOfLists(); //returns union set as a list of list1 and list 2
    public boolean isSubset(); //return true if list2 is subset of list1
}
