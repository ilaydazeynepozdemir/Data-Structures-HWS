/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HW05;

import java.util.ArrayList;
import java.util.List;

/**
 * Part3
 *
 * @author ilayda
 * @param <E>
 */
public class SortedLists<E extends Comparable<E>> extends Abs_SortedLists {

    private List<E> list1;
    private List<E> list2;

    public SortedLists(List<E> given_list1, List<E> given_list2) {
        this.list1 = sort(given_list1);//sort edip koy!
        this.list2 = sort(given_list2);
    }

    /**
     * #####private #####
     */
    /**
     * verilen list nullsa null return eder
     *
     * @param given_list_
     * @return
     */
    private List sort(List<E> given_list_) {/*aldigini degistirme burayi duzelt!!!!!!!*/

        if (given_list_ == null) {
            return null;
        }
        List<E> sortedList = new ArrayList();
        for (int i = 0; i < given_list_.size(); ++i) {
            sortedList.add(given_list_.get(i));
        }
        for (int i = 1; i < sortedList.size(); i++) {
            int j = i;
            E temp = (E) sortedList.get(i);
            while ((j > 0) && ((sortedList.get(j - 1).compareTo(temp)) == 1)) {
                sortedList.set(j, sortedList.get(j - 1));
                j--;
            }
            sortedList.set(j, temp);
        }
        return sortedList;
    }

    /**
     * gonderilen eleman gonderilen list icinde var mi diye bakar
     *
     * @param element gonderilen eleman
     * @param list_ bakilacak liste
     * @param index listenin baslangic indexi (0 olarak gonderilirse bastan sona
     * kotrol eder)
     * @return varsa true yoksa false
     */
    private boolean hasElement(E element, List<E> list_, int index) {
        try {
            if (index == list_.size()) {
                return false;
            } else if (element.equals(list_.get(index))) {
                return true;
            } else {
                return hasElement(element, list_, index + 1);
            }
        } catch (NullPointerException ex) {
            return false;
        }
    }

    /**
     * list1'in elemani list2 de var mi diye kontrol edilir kesisimleri
     * parametre olarak gonderilen listeye eklenir recursive
     *
     * @param index1 list1 in baslangic indexi
     * @param intersectList kesisim listesi
     * @return kesisim listesine eklenirse true eklenmezse false doner
     */
    private boolean intersectionOfLists(int index1, List<E> intersectList) {
        try {
            if (index1 == list1.size()) {
                return false;
            } else if (controlSecondList(list1.get(index1), 0) && (!hasElement(list1.get(index1), intersectList, 0))) {
                intersectList.add(list1.get(index1));
                intersectionOfLists(index1 + 1, intersectList);
                return true;
            } else {
                return intersectionOfLists(index1 + 1, intersectList);
            }
        } catch (NullPointerException ex) {
            return false;
        }
    }

    /**
     * gonderilen eleman ikinci liste icinde var mi diye bakar
     *
     * @param el1 bakilacak eleman
     * @param index2 list2nin baslangic indexi
     * @return varsa true doner
     */
    private boolean controlSecondList(E el1, int index2) {
        try {
            if (index2 == list2.size()) {
                return false;
            } else if (el1.equals(list2.get(index2))) {
                //System.out.println(el1);
                return true;
            } else {
                return controlSecondList(el1, index2 + 1);
            }
        } catch (NullPointerException ex) {
            return false;
        }
    }

    /**
     * kesisim olmayani birlesim listesine ekler
     *
     * @param index1 list1in baslangic indexi
     * @param unionList birlesim listesi
     * @return eklenirse true eklenemezse false doner
     */
    private boolean unionOfList(int index1, List<E> unionList) {//kesisim olmayani ekler
        try {
            if (index1 == list1.size()) {
                return false;
            } else if (!controlSecondList(list1.get(index1), 0)) {
                unionList.add(list1.get(index1));
                unionOfList(index1 + 1, unionList);
                return true;
            } else {
                return unionOfList(index1 + 1, unionList);
            }
        } catch (NullPointerException ex) {
            return false;
        }
    }

    /**
     * list2 birlesim listesine eklenir
     *
     * @param index list2 baslangic indexi
     * @param Union birlesim listesi
     * @return eklenirse true
     */
    private boolean addList2InUnion(int index, List<E> Union) {
        try {
            if (index == list2.size()) {
                return false;
            } else if (!hasElement(list2.get(index), Union, 0)) {//bu elemana sahip degilse ekliyorum
                // System.out.println(list2.get(index));
                Union.add(list2.get(index));
                addList2InUnion(index + 1, Union);
                return true;
            } else {
                return addList2InUnion(index + 1, Union);
            }
        } catch (NullPointerException ex) {
            return false;
        }
    }

    /**
     * list2 elemani list1 icinde varsa counter arttirilir
     *
     * @param index list2 indexi
     * @param counter kac list2 elemaninin list1 icinde varoldugunu bulmak icin
     * @return counteri return eder
     */
    private int isSubset(int index, int counter) {

        if (index == list2.size()) {
            return counter;
        } else if (hasElement(list2.get(index), list1, 0)) {
            return isSubset(index + 1, counter + 1);
        } else {
            return counter;
        }

    }

    /**
     * #####public#####
     */
    /**
     * class icindeki iki listenin kesisimini verir
     *
     * @return kesisim listesi return edilir
     */
    @Override
    public List<E> intersectionOfLists() { //returns intersection set as a list of list1 and list2
        List<E> returnList = new ArrayList();
        intersectionOfLists(0, returnList);
        return returnList;
    }

    /**
     * class icindeki iki listenin birlesimini verir
     *
     * @return birlesim listesi
     */
    @Override
    public List unionOfLists() { //returns union set as a list of list1 and list 2
        List union = new ArrayList();
        //ikinci liste tamamen eklenir
        addList2InUnion(0, union);//recursive
        //kesisimleri haric birinci liste eklenir
        unionOfList(0, union);//recursive
        return union;
    }

    /**
     * list2 list1'in alt kumesimi diye bakar
     *
     * @return alt kumesiyse true degilse false
     */
    @Override
    public boolean isSubset() { //return true if list2 is subset of list1
        if (list2 == null) {
            return true;//bos kume butun kumelerin alt kumesi
        } else if (list2.size() > list1.size()) {//list2 list1den buyukse subset degildir
            return false;
        } else {
            int count = isSubset(0, 0);
            return (count == list2.size());
        }
    }

}
