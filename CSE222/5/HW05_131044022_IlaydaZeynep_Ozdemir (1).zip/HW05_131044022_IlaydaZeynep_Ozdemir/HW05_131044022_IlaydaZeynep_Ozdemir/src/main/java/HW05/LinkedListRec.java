package HW05;

/**
 * Part2
 *
 * @author ilayda
 * @param <E>
 */
public class LinkedListRec<E> extends Abs_LinkedListRec<E> {

    /**
     * Constructor
     */
    public LinkedListRec() {
        head = null;
    }
    /**
     *  #####private #####
     */
    
    /**
     * listenin basini tutar
     */
    private Node<E> head;

    /**
     * inner class disaridan erisilemez
     *
     * @param <E> E tipinde veri tutar
     */
    private static class Node<E> {

        private E data;
        private Node<E> next;

        /**
         * inner classin constructori
         *
         * @param given_data
         */
        private Node(E given_data) {
            data = given_data;
            next = null;
        }
    }

    /**
     * size-private
     *
     * @param head listenin basini alir recurcive
     * @return size i return eder
     */
    private int size(Node<E> head) {
        if (head == null) {
            return 0;
        } else {
            return 1 + size(head.next);
        }
    }

    /**
     * private toString-recursive
     *
     * @param head liste basi
     * @return listenin string hali
     */
    private String toString(Node<E> head) {
        if (head == null) {
            return "";
        } else {
            return head.data + " " + toString(head.next);
        }
    }

    /**
     * listeye ekleme-private
     *
     * @param head liste basi
     * @param data eklenecek data
     */
    private void add(Node<E> head, E data) {
        if (head.next == null) {
            head.next = new Node<E>(data);
        } else {
            add(head.next, data);
        }
    }

    /**
     * Bir eleman siler-ilk gordugu- private
     *
     * @param head
     * @param pred
     * @param outData
     * @return
     */
    private boolean removeOneElement(Node< E> head, Node< E> pred, E outData) {
        if (head == null) {
            return false;
        } else if (head.data.equals(outData)) {
            pred.next = head.next;
            return true;
        } else {
            return removeOneElement(head.next, head, outData);
        }
    }

    /**
     * private verilen datayi her gordugunde siler
     *
     * @param head
     * @param outData
     * @return silebilirse true
     */
    private boolean remove(Node<E> head, E outData) {//istenilen remove
        if (head == null) {
            return false;
        } else {
            //System.out.println(head.data);
            if (head.data.equals(outData)) {
                remove(head.next, outData);
                return removeOneElement(outData);
            } else {
                return remove(head.next, outData);
            }
        }
    }

    /**
     * #####public #####
     */
    /**
     * listeye ekleme
     *
     * @param data eklenecek data
     */
    public void add(E data) {
        if (head == null) {
            head = new Node<E>(data);
        } else {
            add(head, data);
        }
    }

    /**
     * Ilk gordugunu siler tekrarlari kalir
     *
     * @param outData silinecek eleman
     * @return silerse true silemezse false
     */
    public boolean removeOneElement(E outData) {//1 tane siler
        if (head == null) {
            return false;
        } else if (head.data.equals(outData)) {
            head = head.next;
            //remove(outData);
            return true;
        } else {
            return removeOneElement(head.next, head, outData);
        }
    }

    /**
     * verilen datayi komple listeden kaldirir (Her gordugu outDataya esit liste
     * elemanini siler)
     *
     * @param outData silinecek data
     * @return silerse true silemezse false
     */
    @Override
    public boolean remove(E outData) {//istenilen remove
        return remove(head, outData);
    }

    /**
     * icinde recursive fonksiyonu cagirir listenin sizeini verir
     *
     * @return size i return eder
     */
    @Override
    public int size() {
        return size(head);
    }

    /**
     * objectnin to stringi override edilir
     *
     * @return listenin string hali
     */
    @Override
    public String toString() {
        return toString(head);
    }

}
